# MOF-DAC-ML

Data and code supporting the manuscript

> **Prediction of CO₂ Uptake and Surrogate Modeling of Specific Heat Capacity Using Explainable Machine Learning for Multi-Property Screening of Metal–Organic Frameworks for Direct Air Capture**
>
> S. Nikkhah, S. Zendehboudi, H. Mashhadimoslem, N. M. Cata Saady, A. Azarpour
> *Energy & Fuels* (manuscript ID ef-2026-02955k)

The repository contains the curated dataset, the scripts for all six models and both targets, the fixed train/test split indices, and the scripts that produce the interpretation figures, so that every value in Table 2, Tables S-3 to S-6 and Figs. 5, 6, 8, 9, 10 and S-3 can be reproduced.

## Study overview

Six machine learning models are trained on 1,019 literature-reported experimental CO₂ adsorption data points for 57 metal–organic frameworks (MOFs):

- Decision Tree (DT)
- Random Forest (RF)
- Extreme Gradient Boosting (XGBoost)
- CSA-LSSVM 
- Artificial Neural Network (ANN, MATLAB)
- Adaptive Neuro-Fuzzy Inference System (ANFIS, MATLAB)

Two targets are modeled:

1. **CO₂ uptake** (mmol/g), measured experimentally.
2. **Specific heat capacity, Cp** (J/(g·K)). These values are **ML-derived**: they come from the XGBoost model of Moosavi et al. (2022) via the CoRE MOF database, not from measurements. The Cp models therefore reproduce a reference surrogate; their accuracy is not a validation of heat-capacity prediction. CO₂ uptake and the MOF identifier are excluded from the Cp model inputs.

Each model is evaluated under two protocols:

- **Random 80/20 split** (interpolation within the represented frameworks), and
- **Leave-one-MOF-out (LOMO)** validation, in which all data points of one framework are held out in turn (prediction for frameworks excluded from training).

Interpretation uses gain-based feature importance (random-split model) and SHAP values (computed on the held-out LOMO predictions). Predictions at DAC-relevant conditions (4×10⁻⁴ bar, 273–313 K) are reported as a descriptive summary only: the dataset contains 13 points at p(CO₂) ≤ 0.001 bar, so these predictions are extrapolations for nearly all frameworks and are not a ranking of DAC performance.

## Repository structure

```text
.
├── data/
│   ├── MLDAC01.xlsx                  # modeling dataset: 1,019 rows, 57 MOFs (one row per data point)
│   ├── MLDACDATA.xlsx                # Table S-1: one row per MOF entry, with source DOI and table/figure locator
│   └── splits/
│       ├── CO2_split_indices.csv     # 80/20 split for CO2 uptake (815 train / 204 test)
│       ├── Cp_CSA_split_indices.csv  # 80/20 split for Cp (810 train / 202 test)
│       └── Cp_CSA_predictions_randomsplit.csv   # used only for the row-order check in the MATLAB Cp scripts
│
├── src/
│   ├── codes/                        # models
│   │   ├── lomo_common.py            # shared helpers: data loading, one-hot encoding, random split, LOMO, metrics
│   │   ├── cp_lomo_v2.py             # same helpers as lomo_common.py (imported by the Cp notebooks)
│   │   ├── cp_pipeline.py            # Cp tuning / evaluation pipeline used by the Cp notebooks
│   │   ├── DT.ipynb                  # CO2 uptake – Decision Tree
│   │   ├── RF.ipynb                  # CO2 uptake – Random Forest
│   │   ├── xgboost.ipynb             # CO2 uptake – XGBoost
│   │   ├── CSA-LSSVM.ipynb           # CO2 uptake – CSA-LSSVM (Python)
│   │   ├── ann_CO2.m                 # CO2 uptake – ANN (MATLAB)
│   │   ├── ANFIS_CO2.m               # CO2 uptake – ANFIS (MATLAB)
│   │   ├── CpDT.ipynb                # Cp – Decision Tree
│   │   ├── CpRF.ipynb                # Cp – Random Forest
│   │   ├── CpXGBoost.ipynb           # Cp – XGBoost
│   │   ├── CpCSA-LSSVM.ipynb         # Cp – CSA-LSSVM (Python)
│   │   ├── ANNCp.m                   # Cp – ANN (MATLAB)
│   │   └── ANFIS_CP.m                # Cp – ANFIS (MATLAB)
│   │
│   └── figures/                      # interpretation and summary figures
│       ├── Fig5_CO2_gain.py          # Fig. 5  – gain importance, CO2 uptake
│       ├── SHAP_LOMO_panels.py       # Fig. 6 (TARGET = "CO2") and Fig. 9 (TARGET = "Cp") – SHAP under LOMO
│       ├── Fig8_Cp_gain.py           # Fig. 8  – gain importance, Cp
│       ├── Fig11_Cp_by_family_metal.py   # Fig. 10 – mean reference Cp by MOF family and metal
│       ├── Fig7_SI.py                # Fig. S-3 and Table S-6 – predictions at DAC-relevant conditions
│       └── XGB_LOMO_bestparams_onehot_perfold.csv   # per-framework LOMO results used by Fig7_SI.py
│
├── requirements.txt
├── LICENSE
└── README.md
```

## Setup

Python 3.13 (Anaconda) was used for the Python scripts:

```bash
pip install -r requirements.txt
```

The MATLAB scripts were run in MATLAB R2025b with the Statistics and Machine Learning Toolbox, the Deep Learning Toolbox (ANN) and the Fuzzy Logic Toolbox (ANFIS).

SHAP values and gain importance can differ slightly between XGBoost versions; use the version pinned in `requirements.txt` to reproduce the reported numbers exactly.

## How to run

All scripts read their input files from the folder they are run in. Copy the dataset and split files next to the scripts first:

```bash
cp data/MLDAC01.xlsx data/splits/*.csv src/codes/
cp data/MLDAC01.xlsx src/figures/
cp src/codes/lomo_common.py src/codes/cp_lomo_v2.py src/figures/
```

Then run each notebook or script from its own folder (`src/codes/` or `src/figures/`).

| Result in the paper | Script(s) |
|---|---|
| Table 2, Tables S-3 and S-4 (CO₂ uptake) | `DT.ipynb`, `RF.ipynb`, `xgboost.ipynb`, `CSA-LSSVM.ipynb`, `ann_CO2.m`, `ANFIS_CO2.m` |
| Table 2, Table S-3 (Cp) | `CpDT.ipynb`, `CpRF.ipynb`, `CpXGBoost.ipynb`, `CpCSA-LSSVM.ipynb`, `ANNCp.m`, `ANFIS_CP.m` |
| Fig. 5 / Fig. 8 (gain importance) | `Fig5_CO2_gain.py`, `Fig8_Cp_gain.py` |
| Fig. 6 / Fig. 9 (SHAP under LOMO) | `SHAP_LOMO_panels.py` |
| Fig. 10 (Cp by MOF family and metal) | `Fig11_Cp_by_family_metal.py` |
| Fig. S-3, Table S-6 (DAC-relevant conditions) | `Fig7_SI.py` |

Run times: the full hyperparameter searches and the 57-fold (CO₂) or 54-fold (Cp) LOMO loops take from minutes (tree models) to several hours (ANN, ANFIS) on a desktop computer.

## Reproducibility

- **Random seeds.** The 80/20 split uses seed 42 (`numpy.random.RandomState(42)`). Cross-validation and model seeds are fixed in each script (`random_state = 42`; MATLAB `rng(42)`).
- **Split indices.** The exact training and testing rows are given in `data/splits/`. The MATLAB scripts read these files and stop if the row order differs, so all six models are evaluated on the same test points.
- **No leakage across frameworks in LOMO.** In every LOMO fold, one-hot encoding, scaling and (for ANN and ANFIS) early stopping use only the training frameworks.
- **Hyperparameters.** The search ranges and the selected values are reported in Tables S-2 (CO₂ uptake) and S-7 (Cp).

## Data

`data/MLDAC01.xlsx` contains the 1,019 data points used for modeling. Columns:

| Column | Description |
|---|---|
| `MOF_ID` | framework identifier (used only for grouping in LOMO, never as an input) |
| `MetalType`, `Topology`, `Lp`, `Ls`, `SynthesisMethod` | categorical descriptors (one-hot encoded) |
| `LCD`, `PLD` | largest cavity and pore limiting diameter (Å) |
| `BET` | BET surface area (m²/g) |
| `Vp` | pore volume (cm³/g) |
| `ThermalSatb` | thermal stability (°C) |
| `Enthalpy` | CO₂ adsorption enthalpy (kJ/mol) |
| `Cp` | ML-derived specific heat capacity (J/(g·K)) |
| `T`, `P` | temperature (K) and CO₂ pressure (bar) |
| `CO2uptake` | experimental CO₂ uptake (mmol/g) |



`data/MLDACDATA.xlsx` is Table S-1 of the Supporting Information: one row per MOF entry with the literature source (DOI) and the table or figure of the source from which the data were taken.



## Citation

If you use the data or code, please cite the article (citation will be added on publication).

## License

Released under the MIT License — see `LICENSE`.
