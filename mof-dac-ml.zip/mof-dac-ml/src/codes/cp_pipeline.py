"""
cp_pipeline.py -- shared pipeline for the Cp-as-target tree models
(CpDT_v2, CpRF_v2, CpXGBoost_v2). Oct 2026.

Protocol (identical for every model):
  1. Load data, target = Cp; drop CO2uptake and MOF_ID from the inputs.
     Rows without Cp are dropped (expected 1,012 rows / 54 MOFs).
  2. One random 80/20 split, seed 42 (same indices as lomo_common.run_random_split).
  3. Hyperparameter grid search by 3-fold CV R2 on the TRAINING split only
     (one-hot categories from training rows only). The test rows are never
     seen during tuning.
  4. Section A: CV-best model trained on the training split -> train / test / all
     metrics (R2, MSE, RMSE, MAE, AARE) + bootstrap 95% CI on the test metrics.
  5. Section B: LOMO with the SAME CV-best hyperparameters (no re-selection on
     LOMO folds), with per-fold metrics, pooled metrics and SHAP (tree models).
  6. Section D: top-5 CV candidates evaluated under LOMO for SENSITIVITY ONLY;
     not used to choose the reported model.
  7. Saves <PREFIX>_COMPREHENSIVE_RESULTS.xlsx plus CSVs with every prediction
     and the split indices.

Set the environment variable CP_QUICK_TEST=1 to run only the first few grid
combinations (for checking that the script runs; NOT for reported results).
"""

import os
import time
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold

from cp_lomo_v2 import load_dataset, encode_fold_onehot, run_lomo, run_random_split, regression_metrics

TARGET = "Cp"
GROUP_COL = "MOF_ID"
DROP_FROM_INPUTS = ["CO2uptake"]
LIKELY_NUMERIC = ["LCD", "PLD", "ThermalSatb", "BET", "Vp", "Enthalpy", "T", "P"]
SEED = 42
TEST_RATIO = 0.20
KFOLD = 3
CV_SEED = 1000
N_BOOTSTRAP = 1000
N_SENSITIVITY = 5


def metrics_row(label, y_true, y_pred):
    r2, rmse, mae, aare = regression_metrics(y_true, y_pred)
    return {"Set": label, "N": len(y_true), "R2": r2, "MSE": rmse ** 2, "RMSE": rmse, "MAE": mae, "AARE_pct": aare}


def load_cp_data(file_path):
    X_raw, y, groups, cat_cols, num_cols = load_dataset(file_path, TARGET, GROUP_COL, LIKELY_NUMERIC)
    X_raw = X_raw.drop(columns=[c for c in DROP_FROM_INPUTS if c in X_raw.columns])
    cat_cols = [c for c in cat_cols if c in X_raw.columns]
    num_cols = [c for c in num_cols if c in X_raw.columns]
    assert TARGET not in X_raw.columns and GROUP_COL not in X_raw.columns
    assert not any(c in X_raw.columns for c in DROP_FROM_INPUTS)
    return X_raw, y, groups, cat_cols, num_cols


def cv_score(X, y, factory):
    r2s, rmses = [], []
    for tr, va in KFold(n_splits=KFOLD, shuffle=True, random_state=CV_SEED).split(X):
        m = factory()
        m.fit(X.iloc[tr], y[tr])
        r2, rmse, _, _ = regression_metrics(y[va], m.predict(X.iloc[va]))
        r2s.append(r2)
        rmses.append(rmse)
    return float(np.mean(r2s)), float(np.std(r2s)), float(np.mean(rmses))


def run_cp_pipeline(model_name, file_path, out_prefix, build_grid, make_factory,
                    shap_factory=None, extra_settings=None):
    """
    build_grid(n_features) -> list of parameter dicts (the search grid)
    make_factory(params)   -> callable returning a fresh unfitted model
    shap_factory(model)    -> SHAP explainer, or None to skip SHAP
    """
    t0 = time.time()
    quick = os.environ.get("CP_QUICK_TEST", "0") == "1"
    sheets = {}

    X_raw, y, groups, cat_cols, num_cols = load_cp_data(file_path)
    n, n_mofs = len(y), len(np.unique(groups))
    print(f"{model_name} | target {TARGET} | {n} rows across {n_mofs} MOFs")
    print(f"Numeric inputs ({len(num_cols)}): {num_cols}")
    print(f"Categorical inputs ({len(cat_cols)}): {cat_cols}\n")

    # ---------------- split (identical to run_random_split) ----------------
    idx = np.random.RandomState(SEED).permutation(n)
    n_test = round(TEST_RATIO * n)
    test_idx, train_idx = idx[:n_test], idx[n_test:]
    Xtr_enc, _ = encode_fold_onehot(X_raw.iloc[train_idx], X_raw.iloc[test_idx], cat_cols, num_cols)
    ytr = y[train_idx]

    # ---------------- Stage 1: grid search on TRAINING split only ----------------
    grid = build_grid(Xtr_enc.shape[1])
    if quick:
        grid = grid[:6]
        print("*** CP_QUICK_TEST=1: only the first 6 grid combinations are searched ***")
    print("#" * 70 + f"\nGrid search: {len(grid)} combinations, {KFOLD}-fold CV on the training split only\n" + "#" * 70)
    rows = []
    for i, p in enumerate(grid, 1):
        r2m, r2s, rmsem = cv_score(Xtr_enc, ytr, make_factory(p))
        rows.append({**p, "CV_R2_mean": r2m, "CV_R2_std": r2s, "CV_RMSE_mean": rmsem})
        if i % max(1, len(grid) // 10) == 0 or i == len(grid):
            print(f"  {i}/{len(grid)} done ({time.time() - t0:.0f} s)")
    search = pd.DataFrame(rows).sort_values(["CV_R2_mean", "CV_RMSE_mean"], ascending=[False, True]).reset_index(drop=True)
    search.insert(0, "CV_rank", np.arange(1, len(search) + 1))
    sheets["Stage1_Search"] = search
    param_keys = list(grid[0].keys())
    top = [{k: search.loc[r, k] for k in param_keys} for r in range(min(N_SENSITIVITY, len(search)))]
    best = top[0]
    print("\nTop 5 (CV on training split):")
    print(search.head(5).to_string(index=False))

    # ---------------- Section A: random split ----------------
    print("\n" + "#" * 70 + "\nSECTION A: random 80/20 split (CV-best hyperparameters)\n" + "#" * 70)
    factory = make_factory(best)
    rs = run_random_split(X_raw, y, factory, cat_cols, num_cols, test_ratio=TEST_RATIO, seed=SEED)
    assert np.array_equal(rs["test_idx"], test_idx), "split mismatch"
    p_tr = rs["model"].predict(rs["X_train_enc"])
    p_te = rs["model"].predict(rs["X_test_enc"])
    A = pd.DataFrame([metrics_row("Train", y[train_idx], p_tr), metrics_row("Test", y[test_idx], p_te),
                      metrics_row("All", np.concatenate([y[train_idx], y[test_idx]]), np.concatenate([p_tr, p_te]))])
    print(A.round(5).to_string(index=False))
    sheets["A_RandomSplit_Summary"] = A

    pd.DataFrame({"row_index": np.concatenate([train_idx, test_idx]),
                  "MOF": np.concatenate([groups[train_idx], groups[test_idx]]),
                  "set": ["train"] * len(train_idx) + ["test"] * len(test_idx),
                  "y_true": np.concatenate([y[train_idx], y[test_idx]]),
                  "y_pred": np.concatenate([p_tr, p_te])}).to_csv(f"{out_prefix}_predictions_randomsplit.csv", index=False)
    pd.DataFrame({"row_index": idx, "set": ["test"] * n_test + ["train"] * (n - n_test)}).to_csv(
        f"{out_prefix}_split_indices.csv", index=False)

    rb = np.random.RandomState(SEED)
    yt = y[test_idx]
    boots = np.array([regression_metrics(yt[b], p_te[b]) for b in (rb.randint(0, n_test, size=n_test) for _ in range(N_BOOTSTRAP))], dtype=float)
    sheets["A2_Bootstrap_CI"] = pd.DataFrame([
        {"Metric": m, "Point": A.loc[1, m], "CI_lower": np.nanpercentile(boots[:, k], 2.5),
         "CI_upper": np.nanpercentile(boots[:, k], 97.5)} for k, m in enumerate(["R2", "RMSE", "MAE", "AARE_pct"])])

    # ---------------- Section B: LOMO with the CV-best hyperparameters ----------------
    print("\n" + "#" * 70 + "\nSECTION B: LOMO (CV-best hyperparameters, no re-selection)\n" + "#" * 70)
    lomo = run_lomo(X_raw, y, groups, factory, cat_cols, num_cols, encode_fn=encode_fold_onehot,
                    run_shap=shap_factory is not None, shap_explainer_factory=shap_factory,
                    verbose_every=10, checkpoint_path=f"{out_prefix}_LOMO_checkpoint.xlsx")
    yt_p, yp_p = np.asarray(lomo["y_true_pooled"]), np.asarray(lomo["y_pred_pooled"])
    B = pd.DataFrame([metrics_row("LOMO pooled", yt_p, yp_p)])
    B["N_MOFs"] = n_mofs
    B["Failed_folds"] = int(lomo["fold_df"]["Error"].notna().sum())
    print(B.round(5).to_string(index=False))
    sheets["B_LOMO_Summary"] = B
    sheets["B_LOMO_PerFold"] = lomo["fold_df"]
    if lomo["shap_ranking"] is not None:
        sheets["F_SHAP_Importance_LOMO"] = lomo["shap_ranking"]
        print("\nSHAP (mean |SHAP|, pooled over LOMO folds):")
        print(lomo["shap_ranking"].head(10).to_string(index=False))
    pd.DataFrame({"MOF": lomo["fold_id_pooled"], "y_true": yt_p, "y_pred": yp_p}).to_csv(
        f"{out_prefix}_predictions_LOMO.csv", index=False)

    # ---------------- Section D: sensitivity (reporting only) ----------------
    print("\n" + "#" * 70 + f"\nSECTION D: LOMO sensitivity for the top {len(top)} CV candidates (reporting only)\n" + "#" * 70)
    sens = []
    for k, p in enumerate(top, 1):
        res = lomo if k == 1 else run_lomo(X_raw, y, groups, make_factory(p), cat_cols, num_cols,
                                           encode_fn=encode_fold_onehot, run_shap=False, verbose_every=10 ** 6)
        sens.append({"CV_rank": k, **p, "CV_R2_mean": search.loc[k - 1, "CV_R2_mean"],
                     "LOMO_R2_pooled": res["R2_pooled"], "LOMO_RMSE_pooled": res["RMSE_pooled"],
                     "LOMO_AARE_pooled": res["AARE_pooled"], "Used_for_reported_results": k == 1})
        print(f"  CV rank {k}: LOMO R2 = {res['R2_pooled']:.4f}")
    sheets["D_LOMO_Sensitivity_Top5"] = pd.DataFrame(sens)

    settings = [("Model", model_name), ("Data file", file_path), ("Target", TARGET), ("Rows used", n), ("MOFs", n_mofs),
                ("Inputs dropped", ", ".join(DROP_FROM_INPUTS + [GROUP_COL])),
                ("Split", f"random 80/20, seed {SEED}: {n - n_test} train / {n_test} test"),
                ("Tuning", f"grid search, {len(grid)} combinations, {KFOLD}-fold CV R2 on training split only (KFold seed {CV_SEED})"),
                ("Best hyperparameters", str({k: (v.item() if hasattr(v, 'item') else v) for k, v in best.items()})),
                ("LOMO hyperparameters", "same CV-best; no selection on LOMO folds"),
                ("Quick test mode", "YES - not for reporting" if quick else "no"),
                ("Run time (s)", round(time.time() - t0))]
    settings += list(extra_settings or [])
    sheets = {"0_Settings": pd.DataFrame(settings, columns=["Setting", "Value"]), **sheets}

    out_xlsx = f"{out_prefix}_COMPREHENSIVE_RESULTS.xlsx"
    with pd.ExcelWriter(out_xlsx, engine="openpyxl") as w:
        for name, df in sheets.items():
            df.to_excel(w, sheet_name=name[:31], index=False)
    print(f"\nSaved: {out_xlsx}, {out_prefix}_predictions_randomsplit.csv, "
          f"{out_prefix}_predictions_LOMO.csv, {out_prefix}_split_indices.csv  ({time.time() - t0:.0f} s)")
    return sheets
