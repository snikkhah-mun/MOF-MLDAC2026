%% ============================================================
%  ANFIS -- Cp as TARGET 
%% ============================================================

set(0,'DefaultFigureWindowStyle','docked');
clear; clc; close all;

%% ---------------- SAVE DIRECTORY ----------------
scriptFullPath = mfilename('fullpath');
[saveDir,~,~] = fileparts(scriptFullPath);
if isempty(saveDir), saveDir = pwd; end
fprintf("All results will be saved to:\n%s\n", saveDir);

%% ---------------- USER SETTINGS ----------------
filePath   = "MLDAC01.xlsx";
targetName = "Cp";
groupCol   = "MOF_ID";
dropInputs = ["MOF_ID", "CO2uptake"];      % never used as inputs
splitFile  = "Cp_CSA_split_indices.csv";
checkFile  = "Cp_CSA_predictions_randomsplit.csv";
outPrefix  = "ANFIS_Cp_";

Kfold = 3;
rng(42);

saveTablesToExcel = true;
saveFigures       = true;
runLOMO           = true;

% Grid search (same as ANF02.m: 6 x 7 x 4 = 168 combos)
search_Radius   = [0.30 0.40 0.50 0.60 0.70 0.80];
search_TopK     = [8 10 12 14 16 18 22];
search_StepSize = [0.005 0.01 0.02 0.03];

GS_MaxEpoch    = 60;
GS_ErrorGoal   = 0;
GS_DecRate     = 0.9;
GS_IncRate     = 1.1;
GS_OptMethod   = 1;      % 1 = hybrid, 0 = backprop
FINAL_MaxEpoch = 800;    % used for the final model AND for every LOMO fold
RANGE_MIN      = 1e-6;

% MF type. 'gaussmf' uses subtractive clustering (Radius is used).
% Any other type uses genfis1 grid partitioning with numMFs per input:
% with TopK up to 22 inputs that gives 2^22 rules, so keep 'gaussmf'
% unless you used something else for the CO2 model.
mfType = 'gaussmf';
numMFs_for_genfis1 = 2;
fprintf("MF type: %s\n", mfType);

%% ============================================================
%  LOAD DATA
%% ============================================================
Traw = readtable(filePath,"PreserveVariableNames",true);
for c = [targetName, groupCol]
    if ~ismember(c, string(Traw.Properties.VariableNames))
        error("Column '%s' not found in Excel headers.", c);
    end
end

% Remove rows with missing target (same rule as the Python scripts)
Traw = Traw(~ismissing(Traw.(targetName)),:);

Y_all  = double(Traw.(targetName));
groups = string(Traw.(groupCol));

Xtab = removevars(Traw, targetName);
Xtab = removevars(Xtab, intersect(dropInputs, string(Xtab.Properties.VariableNames)));
assert(~any(ismember(dropInputs, string(Xtab.Properties.VariableNames))), ...
    "Leak columns (MOF_ID / CO2uptake) are still in the inputs.");

for j = 1:width(Xtab)
    v = Xtab.(j);
    if isstring(v) || ischar(v) || iscellstr(v)
        Xtab.(j) = categorical(string(v));
    end
end

N = height(Xtab);
assert(all(isfinite(Y_all)), "Non-finite Cp values found; row order would no longer match Python.");
fprintf("Target: %s | %d rows across %d MOFs\nInputs: %s\n", targetName, N, ...
    numel(unique(groups)), strjoin(string(Xtab.Properties.VariableNames), ", "));

%% ============================================================
%  OUTER SPLIT: same rows as the Python Cp models
%% ============================================================
S = readtable(splitFile, "TextType", "string");
idxTest  = S.row_index(S.set == "test")  + 1;    % Python is 0-based
idxTrain = S.row_index(S.set == "train") + 1;
assert(numel(idxTest) + numel(idxTrain) == N, ...
    "Split file has %d rows but MATLAB loaded %d rows.", numel(idxTest) + numel(idxTrain), N);

P = readtable(checkFile, "TextType", "string");
assert(max(abs(Y_all(P.row_index + 1) - P.y_true)) < 1e-9, ...
    "Row order differs from the Python run; do not use these results.");
fprintf("Split check passed: TrainAll=%d | Test=%d\n", numel(idxTrain), numel(idxTest));

X_trainTab_all = Xtab(idxTrain,:);
Y_train_all    = Y_all(idxTrain);
X_testTab      = Xtab(idxTest,:);
Y_test_raw     = Y_all(idxTest);

%% ============================================================
%  GRID SEARCH WITH K-FOLD CV (TrainAll only)
%% ============================================================
[RR, KK, SS] = ndgrid(search_Radius, search_TopK, search_StepSize);
combos = [RR(:), KK(:), SS(:)];
nTotal = size(combos,1);
Radius_arr = combos(:,1); TopK_arr = combos(:,2); Step_arr = combos(:,3);
fprintf("\n=== K-FOLD CV GRID SEARCH (%d folds, %d combos) ===\n", Kfold, nTotal);

rng(1000);
cvInner = cvpartition(numel(Y_train_all),'KFold',Kfold);
foldTr = cell(Kfold,1); foldVl = cell(Kfold,1);
for f = 1:Kfold
    foldTr{f} = training(cvInner,f);
    foldVl{f} = test(cvInner,f);
end

MeanR2_arr = nan(nTotal,1); StdR2_arr = nan(nTotal,1); MeanRMSE_arr = nan(nTotal,1);
MeanMAE_arr = nan(nTotal,1); MeanSMAPE_arr = nan(nTotal,1);
RulesMean_arr = nan(nTotal,1); ParamsMean_arr = nan(nTotal,1);

useParallel = license('test','Distrib_Computing_Toolbox');
if useParallel
    if isempty(gcp('nocreate')), parpool; end
    fprintf("Parallel pool enabled.\n");
    parfor c = 1:nTotal
        [MeanR2_arr(c), StdR2_arr(c), MeanRMSE_arr(c), MeanMAE_arr(c), MeanSMAPE_arr(c), ...
         RulesMean_arr(c), ParamsMean_arr(c)] = eval_one_combo_fast( ...
            Radius_arr(c), TopK_arr(c), Step_arr(c), X_trainTab_all, Y_train_all, foldTr, foldVl, Kfold, ...
            mfType, numMFs_for_genfis1, GS_MaxEpoch, GS_ErrorGoal, GS_DecRate, GS_IncRate, GS_OptMethod, RANGE_MIN);
    end
else
    fprintf("Parallel pool NOT available (running serial).\n");
    for c = 1:nTotal
        fprintf("[%3d/%d] R=%.2f | TopK=%d | Step=%.4f ... ", c, nTotal, Radius_arr(c), TopK_arr(c), Step_arr(c));
        [MeanR2_arr(c), StdR2_arr(c), MeanRMSE_arr(c), MeanMAE_arr(c), MeanSMAPE_arr(c), ...
         RulesMean_arr(c), ParamsMean_arr(c)] = eval_one_combo_fast( ...
            Radius_arr(c), TopK_arr(c), Step_arr(c), X_trainTab_all, Y_train_all, foldTr, foldVl, Kfold, ...
            mfType, numMFs_for_genfis1, GS_MaxEpoch, GS_ErrorGoal, GS_DecRate, GS_IncRate, GS_OptMethod, RANGE_MIN);
        fprintf("MeanR2=%.4f (+/-%.4f)\n", MeanR2_arr(c), StdR2_arr(c));
    end
end

gsResults = table(Radius_arr, TopK_arr, Step_arr, MeanR2_arr, StdR2_arr, MeanRMSE_arr, MeanMAE_arr, ...
    MeanSMAPE_arr, RulesMean_arr, ParamsMean_arr, 'VariableNames', {'Radius','TopK','StepSize', ...
    'MeanR2_CV','StdR2_CV','MeanRMSE_CV','MeanMAE_CV','MeanSMAPE_CV','NumRules_mean','NumParams_mean'});
gsResults_sorted = sortrows(gsResults,'MeanR2_CV','descend','MissingPlacement','last');

best_params = struct('Radius', gsResults_sorted.Radius(1), 'TopK', gsResults_sorted.TopK(1), ...
                     'StepSize', gsResults_sorted.StepSize(1));
fprintf("\n=== BEST (by mean CV R2) ===\nRadius=%.2f | TopK=%d | Step=%.4f | MeanCV R2=%.4f\n", ...
    best_params.Radius, best_params.TopK, best_params.StepSize, gsResults_sorted.MeanR2_CV(1));

if saveTablesToExcel
    writetable(gsResults_sorted, fullfile(saveDir, outPrefix + "CV_grid_results.xlsx"));
end

cfg = struct('mfType', mfType, 'numMFs', numMFs_for_genfis1, 'MaxEpoch', FINAL_MaxEpoch, ...
    'DecRate', GS_DecRate, 'IncRate', GS_IncRate, 'OptMethod', GS_OptMethod, 'RANGE_MIN', RANGE_MIN);

%% ============================================================
%  FINAL TRAINING on TrainAll, evaluation on Test
%% ============================================================
fprintf("\n=== FINAL TRAIN on TrainAll, EVAL on Test ===\n");
[model, trErr, stepSize] = train_anfis_model(X_trainTab_all, Y_train_all, best_params, cfg, true);
assert(~any(startsWith(model.featNames, "MOF_ID") | model.featNames == "CO2uptake"), ...
    "Leak feature in encoded inputs.");
fprintf("Encoded features: %d | used by ANFIS: %d\n", numel(model.featNames), numel(model.usedIdx));

Ytr_hat = predict_anfis_model(model, X_trainTab_all);
Yte_hat = predict_anfis_model(model, X_testTab);
SAFE_EPS = model.SAFE_EPS;

Y_all_used    = [Y_train_all(:); Y_test_raw(:)];
Yhat_all_used = [Ytr_hat(:);     Yte_hat(:)];

[R2tr,RMSEtr,MSEtr,MAEtr,SMAPEtr,AAREtr]       = regression_metrics_plus(Y_train_all, Ytr_hat, SAFE_EPS);
[R2te,RMSEte,MSEte,MAEte,SMAPEte,AAREte]       = regression_metrics_plus(Y_test_raw,  Yte_hat, SAFE_EPS);
[R2all,RMSEall,MSEall,MAEall,SMAPEall,AAREall] = regression_metrics_plus(Y_all_used, Yhat_all_used, SAFE_EPS);

perfTbl = table(["TrainAll"; "Test"; "All"], [numel(Y_train_all); numel(Y_test_raw); numel(Y_all_used)], ...
    [R2tr; R2te; R2all], [MSEtr; MSEte; MSEall], [RMSEtr; RMSEte; RMSEall], [MAEtr; MAEte; MAEall], ...
    [SMAPEtr; SMAPEte; SMAPEall], [AAREtr; AAREte; AAREall], ...
    'VariableNames', {'Split','N','R2','MSE','RMSE','MAE','SMAPE','AARE'});
disp("===== RANDOM-SPLIT PERFORMANCE (ANFIS, Cp) =====");
disp(perfTbl);

if saveTablesToExcel
    writetable(perfTbl, fullfile(saveDir, outPrefix + "RandomSplit_performance.xlsx"));
    writetable(table(model.featNames(:), 'VariableNames', {'Feature'}), fullfile(saveDir, outPrefix + "feature_names.xlsx"));
    writetable(table(model.featNames(model.usedIdx)', 'VariableNames', {'Feature'}), ...
        fullfile(saveDir, outPrefix + "features_used.xlsx"));
    writetable(table([idxTrain(:); idxTest(:)] - 1, [groups(idxTrain); groups(idxTest)], ...
        [repmat("train", numel(idxTrain), 1); repmat("test", numel(idxTest), 1)], ...
        Y_all_used, Yhat_all_used, 'VariableNames', {'row_index','MOF','set','y_true','y_pred'}), ...
        fullfile(saveDir, outPrefix + "predictions_randomsplit.csv"));
    settingsTbl = table(["mfType";"Radius";"TopK";"StepSize";"FINAL_MaxEpoch";"GS_MaxEpoch";"Kfold";"OptMethod"], ...
        [string(mfType); string(best_params.Radius); string(best_params.TopK); string(best_params.StepSize); ...
         string(FINAL_MaxEpoch); string(GS_MaxEpoch); string(Kfold); string(GS_OptMethod)], ...
        'VariableNames', {'Setting','Value'});
    writetable(settingsTbl, fullfile(saveDir, outPrefix + "settings.xlsx"));
end

%% ============================================================
%  LOMO (leave-one-MOF-out) with the same best hyperparameters
%% ============================================================
if runLOMO
    uniqueGroups = unique(groups);
    nF = numel(uniqueGroups);
    fprintf("\n=== LOMO: %d folds | Radius=%.2f TopK=%d Step=%.4f | %d epochs ===\n", ...
        nF, best_params.Radius, best_params.TopK, best_params.StepSize, FINAL_MaxEpoch);

    foldR2 = nan(nF,1); foldRMSE = nan(nF,1); foldMAE = nan(nF,1); foldAARE = nan(nF,1);
    foldN = zeros(nF,1); foldErr = strings(nF,1);
    yT_pool = []; yP_pool = []; g_pool = strings(0,1);

    for f = 1:nF
        teMask = (groups == uniqueGroups(f));
        trMask = ~teMask;
        foldN(f) = sum(teMask);
        try
            model_f = train_anfis_model(Xtab(trMask,:), Y_all(trMask), best_params, cfg, false);
            yP_f = predict_anfis_model(model_f, Xtab(teMask,:));
            yT_f = Y_all(teMask);
            [r2_f, rmse_f, ~, mae_f, ~, aare_f] = regression_metrics_plus(yT_f, yP_f, model_f.SAFE_EPS);
            foldR2(f) = r2_f; foldRMSE(f) = rmse_f; foldMAE(f) = mae_f; foldAARE(f) = aare_f;
            yT_pool = [yT_pool; yT_f(:)];                                 %#ok<AGROW>
            yP_pool = [yP_pool; yP_f(:)];                                 %#ok<AGROW>
            g_pool  = [g_pool; repmat(uniqueGroups(f), numel(yT_f), 1)];  %#ok<AGROW>
            fprintf("  Fold %d/%d | %s | n=%d | R2=%.4f\n", f, nF, uniqueGroups(f), foldN(f), r2_f);
        catch ME
            foldErr(f) = string(ME.message);
            fprintf("  Fold %d/%d | %s | FAILED: %s\n", f, nF, uniqueGroups(f), ME.message);
        end
        foldTbl = table((1:nF)', uniqueGroups, foldN, foldR2, foldRMSE, foldMAE, foldAARE, foldErr, ...
            'VariableNames', {'Fold','MOF','n_test','R2','RMSE','MAE','AARE_pct','Error'});
        try, writetable(foldTbl, fullfile(saveDir, outPrefix + "LOMO_checkpoint.xlsx")); catch, end
    end

    % Pooled metrics: AARE uses the final model's SAFE_EPS (Cp is never near 0)
    [R2p, RMSEp, MSEp, MAEp, ~, AAREp] = regression_metrics_plus(yT_pool, yP_pool, SAFE_EPS);
    pooledTbl = table(R2p, MSEp, RMSEp, MAEp, AAREp, numel(yT_pool), nF, sum(foldErr ~= ""), ...
        'VariableNames', {'R2_pooled','MSE_pooled','RMSE_pooled','MAE_pooled','AARE_pooled', ...
                          'N_pooled','N_MOFs','Failed_folds'});
    disp("===== LOMO POOLED (ANFIS, Cp) =====");
    disp(pooledTbl);

    if saveTablesToExcel
        writetable(foldTbl,   fullfile(saveDir, outPrefix + "LOMO_perfold.xlsx"));
        writetable(pooledTbl, fullfile(saveDir, outPrefix + "LOMO_POOLED_summary.xlsx"));
        writetable(table(g_pool, yT_pool, yP_pool, 'VariableNames', {'MOF','y_true','y_pred'}), ...
            fullfile(saveDir, outPrefix + "predictions_LOMO.csv"));
    end
end

%% ============================================================
%  FIGURES
%% ============================================================
set(0,'DefaultFigureWindowStyle','normal');
xl = "Reference C_p (J g^{-1} K^{-1})";
yl = "Predicted C_p (J g^{-1} K^{-1})";

fig = figure('Name','ANFIS Cp Scatter Plots','Color','w');
tg  = uitabgroup(fig);

[~, ax] = local_newTabAx(tg, '1) Test');
plot_parity(ax, Y_test_raw, Yte_hat, R2te, RMSEte, MAEte, SMAPEte, AAREte, xl, yl, "ANFIS (Cp): Test");
[~, ax] = local_newTabAx(tg, '2) TrainAll');
plot_parity(ax, Y_train_all, Ytr_hat, R2tr, RMSEtr, MAEtr, SMAPEtr, AAREtr, xl, yl, "ANFIS (Cp): TrainAll");

[~, ax] = local_newTabAx(tg, '3) Train + Test');
hold(ax,'on'); grid(ax,'on');
mn = min([Y_all_used; Yhat_all_used]); mx = max([Y_all_used; Yhat_all_used]);
s1 = scatter(ax, Y_train_all, Ytr_hat, 55, 'o', 'filled', 'MarkerFaceAlpha', 0.55);
s2 = scatter(ax, Y_test_raw,  Yte_hat, 70, '^', 'filled', 'MarkerFaceAlpha', 0.75);
plot(ax, [mn mx], [mn mx], 'k--', 'LineWidth', 2);
legend(ax, [s1 s2], {'TrainAll','Test'}, 'Location','best', 'FontName','Times New Roman','FontSize',12);
text(ax, 0.05, 0.95, sprintf('ALL\nR^2 = %.4f\nRMSE = %.4f\nAARE = %.2f', R2all, RMSEall, AAREall), ...
    'Units','normalized','FontName','Times New Roman','FontSize',12,'FontWeight','bold', ...
    'BackgroundColor','white','EdgeColor','black','VerticalAlignment','top');
xlabel(ax, xl, 'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
ylabel(ax, yl, 'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
title(ax, "ANFIS (Cp): Train + Test", 'FontName','Times New Roman','FontSize',14);
axis(ax,'equal'); axis(ax,'tight');

if runLOMO
    [~, ax] = local_newTabAx(tg, '4) LOMO');
    plot_parity(ax, yT_pool, yP_pool, R2p, RMSEp, MAEp, NaN, AAREp, xl, yl, "ANFIS (Cp): LOMO pooled");
end
if saveFigures
    savefig(fig, fullfile(saveDir, outPrefix + "scatter.fig"));
end

% Training error curve (final model)
figErr = figure('Name','ANFIS Cp Error Curve','Color','w');
plot(1:numel(trErr), trErr, 'k-', 'LineWidth', 2); grid on;
xlabel('Epoch','FontName','Times New Roman','FontSize',12,'FontWeight','bold');
ylabel('Training RMSE (scaled)','FontName','Times New Roman','FontSize',12,'FontWeight','bold');
title(sprintf('Training error | MF=%s | final step size=%.4g', mfType, stepSize(end)), ...
    'Interpreter','none','FontName','Times New Roman','FontSize',12);
if saveFigures, saveas(figErr, fullfile(saveDir, outPrefix + "training_error.png")); end

% Spearman ranking of the features used by the final model
figImp = figure('Name','ANFIS Cp Feature Ranking','Color','w');
nShow = min(20, numel(model.usedIdx));
topIdx = model.usedIdx(1:nShow);
scores_show = abs(model.rvec(topIdx)); scores_show = scores_show / max(scores_show + eps);
barh(flipud(scores_show(:)), 'FaceColor', [0.2 0.6 0.4]);
yticks(1:nShow); yticklabels(flipud(cellstr(model.featNames(topIdx)')));
xlabel('|Spearman r| with C_p (normalised)','FontName','Times New Roman','FontSize',12,'FontWeight','bold');
title(sprintf('Top %d inputs used by the final ANFIS (Cp)', nShow),'FontName','Times New Roman','FontSize',12);
set(gca,'FontName','Times New Roman','FontSize',12,'TickLabelInterpreter','none'); grid on;
if saveFigures, saveas(figImp, fullfile(saveDir, outPrefix + "feature_ranking.png")); end

save(fullfile(saveDir, outPrefix + "results.mat"), 'Y_train_all', 'Y_test_raw', 'Ytr_hat', 'Yte_hat', ...
    'best_params', 'perfTbl', 'model');
fprintf("\n=== ANFIS Cp v2 complete ===\n");

%% ============================================================
%  LOCAL FUNCTIONS (must stay at the end of the script)
%% ============================================================
function [model, trErr, stepSize] = train_anfis_model(XTab, Y, params, cfg, showProgress)
    % Full recipe from ANF02.m, fitted on the given training rows only.
    [X, enc] = onehot_fit_transform_fast(XTab);
    [X, Y] = make_finite_pair_numeric(X, Y);
    [XN, normX] = minmax_fit_transform(X);
    [YN, normY] = minmax_fit_transform(Y(:));

    rvec = corr(XN, YN(:), 'Type','Spearman', 'Rows','pairwise');
    rvec(~isfinite(rvec)) = 0;
    [~, order] = sort(abs(rvec),'descend');
    selIdx = order(1:min(params.TopK, numel(order)));
    cr = max(XN(:,selIdx),[],1) - min(XN(:,selIdx),[],1);
    usedIdx = selIdx(cr > 0);
    TrIn = XN(:,usedIdx);

    if strcmpi(cfg.mfType,'gaussmf')
        opt = genfisOptions('SubtractiveClustering','ClusterInfluenceRange',params.Radius);
        fis0 = genfis(TrIn, YN(:), opt);
    else
        fis0 = genfis1([TrIn YN(:)], cfg.numMFs, cfg.mfType);
    end
    for ii = 1:numel(fis0.Inputs)
        lo = fis0.Inputs(ii).Range(1); hi = fis0.Inputs(ii).Range(2);
        if hi - lo < cfg.RANGE_MIN
            mid = (lo+hi)/2;
            fis0.Inputs(ii).Range = [mid-cfg.RANGE_MIN/2, mid+cfg.RANGE_MIN/2];
        end
    end

    trOpt = [cfg.MaxEpoch, 0, params.StepSize, cfg.DecRate, cfg.IncRate];
    disp4 = repmat(logical(showProgress), 1, 4);
    [fis, trErr, stepSize] = anfis([TrIn YN(:)], fis0, trOpt, disp4, [], cfg.OptMethod);
    for ii = 1:numel(fis.Inputs), fis.Inputs(ii).Range = [0,1]; end

    featNames = enc.numVars;
    for j = 1:numel(enc.catVars)
        featNames = [featNames, string(enc.catVars(j)) + "_" + string(enc.catLevels{j}(:)')]; %#ok<AGROW>
    end

    model = struct('fis', fis, 'enc', enc, 'normX', normX, 'normY', normY, 'usedIdx', usedIdx, ...
        'rvec', rvec, 'featNames', featNames, ...
        'SAFE_EPS', max(0.01*median(abs(Y(:)),'omitnan'), 1e-6));
end

function yhat = predict_anfis_model(model, XTab)
    X = onehot_apply_fast(XTab, model.enc);
    X = double(X);
    X(~isfinite(X)) = 0;
    XN = minmax_apply(X, model.normX);
    XN = min(max(XN,0),1);              % same clamp as ANF02.m
    yhat = minmax_inverse(evalfis(model.fis, XN(:,model.usedIdx)), model.normY);
    yhat = yhat(:);
end

function plot_parity(ax, y, yhat, R2, RMSE, MAE, SMAPE, AARE, xl, yl, ttl)
    mn = min([y(:); yhat(:)]); mx = max([y(:); yhat(:)]);
    scatter(ax, y, yhat, 60, 'filled', 'MarkerFaceAlpha', 0.65);
    hold(ax,'on'); grid(ax,'on');
    plot(ax, [mn mx], [mn mx], 'k--', 'LineWidth', 2);
    if isnan(SMAPE)
        s = sprintf('R^2 = %.4f\nRMSE = %.4f\nMAE = %.4f\nAARE = %.2f', R2, RMSE, MAE, AARE);
    else
        s = sprintf('R^2 = %.4f\nRMSE = %.4f\nMAE = %.4f\nSMAPE = %.2f\nAARE = %.2f', R2, RMSE, MAE, SMAPE, AARE);
    end
    text(ax, 0.05, 0.95, s, 'Units','normalized','FontName','Times New Roman','FontSize',12, ...
        'FontWeight','bold','BackgroundColor','white','EdgeColor','black','VerticalAlignment','top');
    xlabel(ax, xl, 'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
    ylabel(ax, yl, 'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
    title(ax, ttl, 'FontName','Times New Roman','FontSize',14);
    axis(ax,'equal'); axis(ax,'tight');
end

function [meanR2,stdR2,meanRMSE,meanMAE,meanSMAPE,meanRules,meanParams] = ...
    eval_one_combo_fast(Radius, TopK, StepSize, X_trainTab_all, Y_train_all, foldTr, foldVl, Kfold, ...
                        mfType, numMFs_for_genfis1, GS_MaxEpoch, GS_ErrorGoal, GS_DecRate, GS_IncRate, GS_OptMethod, RANGE_MIN)
    R2_f = nan(Kfold,1); RMSE_f = nan(Kfold,1); MAE_f = nan(Kfold,1); SMAPE_f = nan(Kfold,1);
    nRules_f = nan(Kfold,1); nParams_f = nan(Kfold,1);
    try
        for f = 1:Kfold
            XtrTab = X_trainTab_all(foldTr{f},:); YtrRaw = Y_train_all(foldTr{f});
            XvlTab = X_trainTab_all(foldVl{f},:); YvlRaw = Y_train_all(foldVl{f});

            [Xtr, enc] = onehot_fit_transform_fast(XtrTab);
            Xvl = onehot_apply_fast(XvlTab, enc);
            [Xtr, YtrRaw] = make_finite_pair_numeric(Xtr, YtrRaw);
            [Xvl, YvlRaw] = make_finite_pair_numeric(Xvl, YvlRaw);

            [XtrN, normX] = minmax_fit_transform(Xtr);
            XvlN = min(max(minmax_apply(Xvl, normX),0),1);
            [YtrN, normY] = minmax_fit_transform(YtrRaw(:));
            SAFE_EPS = max(0.01*median(abs(YtrRaw(:)),'omitnan'), 1e-6);

            rvec = corr(XtrN, YtrN(:), 'Type','Spearman', 'Rows','pairwise');
            rvec(~isfinite(rvec)) = 0;
            [~, order] = sort(abs(rvec),'descend');
            selIdx = order(1:min(TopK, numel(order)));
            TrIn = XtrN(:,selIdx); VlIn = XvlN(:,selIdx);
            keep = (max(TrIn,[],1) - min(TrIn,[],1)) > 0;
            TrIn = TrIn(:,keep); VlIn = VlIn(:,keep);
            if isempty(TrIn) || size(TrIn,1) < 10, continue; end

            if strcmpi(mfType,'gaussmf')
                opt = genfisOptions('SubtractiveClustering','ClusterInfluenceRange',Radius);
                fis0 = genfis(TrIn, YtrN(:), opt);
            else
                fis0 = genfis1([TrIn YtrN(:)], numMFs_for_genfis1, mfType);
            end
            for ii = 1:numel(fis0.Inputs)
                lo = fis0.Inputs(ii).Range(1); hi = fis0.Inputs(ii).Range(2);
                if hi - lo < RANGE_MIN
                    mid = (lo+hi)/2;
                    fis0.Inputs(ii).Range = [mid-RANGE_MIN/2, mid+RANGE_MIN/2];
                end
            end
            nRules = numel(fis0.Rules); nInp = numel(fis0.Inputs);
            nRules_f(f) = nRules; nParams_f(f) = nRules*(nInp+1) + nRules*2*nInp;

            trOpt = [GS_MaxEpoch,GS_ErrorGoal,StepSize,GS_DecRate,GS_IncRate];
            fis_tr = anfis([TrIn YtrN(:)], fis0, trOpt, [false false false false], [], GS_OptMethod);
            for ii = 1:numel(fis_tr.Inputs), fis_tr.Inputs(ii).Range = [0,1]; end

            Yvl_hat = minmax_inverse(evalfis(fis_tr, VlIn), normY);
            [R2_f(f), RMSE_f(f), ~, MAE_f(f), SMAPE_f(f), ~] = regression_metrics_plus(YvlRaw(:), Yvl_hat, SAFE_EPS);
        end
        meanR2 = mean(R2_f,'omitnan'); stdR2 = std(R2_f,'omitnan');
        meanRMSE = mean(RMSE_f,'omitnan'); meanMAE = mean(MAE_f,'omitnan');
        meanSMAPE = mean(SMAPE_f,'omitnan');
        meanRules = mean(nRules_f,'omitnan'); meanParams = mean(nParams_f,'omitnan');
    catch
        meanR2=NaN; stdR2=NaN; meanRMSE=NaN; meanMAE=NaN; meanSMAPE=NaN; meanRules=NaN; meanParams=NaN;
    end
end

function [Xmat, enc] = onehot_fit_transform_fast(T)
    varNames = string(T.Properties.VariableNames);
    n = height(T);
    isCat = false(1,width(T));
    for j = 1:width(T), isCat(j) = iscategorical(T.(j)); end
    numVars = varNames(~isCat); catVars = varNames(isCat);

    Xnum = zeros(n, numel(numVars));
    for j = 1:numel(numVars), Xnum(:,j) = double(T.(numVars(j))); end

    catLevels = cell(1,numel(catVars));
    Xcat = zeros(n,0);
    for j = 1:numel(catVars)
        cats = categories(removecats(T.(catVars(j))));
        catLevels{j} = cats;
        Xcat = [Xcat, local_dummy(T.(catVars(j)), cats)]; %#ok<AGROW>
    end
    Xmat = [Xnum, Xcat];
    enc.numVars = numVars; enc.catVars = catVars; enc.catLevels = catLevels;
end

function Xmat = onehot_apply_fast(T, enc)
    n = height(T);
    Xnum = zeros(n, numel(enc.numVars));
    for j = 1:numel(enc.numVars), Xnum(:,j) = double(T.(enc.numVars(j))); end
    Xcat = zeros(n,0);
    for j = 1:numel(enc.catVars)
        Xcat = [Xcat, local_dummy(T.(enc.catVars(j)), enc.catLevels{j})]; %#ok<AGROW>
    end
    Xmat = [Xnum, Xcat];
end

function D = local_dummy(v, cats)
    % One column per training level; unseen levels -> all zeros.
    % (Replaces dummyvar, which errors on <undefined> values -- these occur
    %  in LOMO when the held-out MOF has a level no training MOF has.)
    v = string(v);
    D = zeros(numel(v), numel(cats));
    for c = 1:numel(cats)
        D(:,c) = double(v == string(cats{c}));
    end
end

function [X,y] = make_finite_pair_numeric(X,y)
    X = double(X); y = double(y(:));
    X(~isfinite(X)) = NaN; y(~isfinite(y)) = NaN;
    bad = isnan(y);
    X(bad,:) = []; y(bad) = [];
    for j = 1:size(X,2)
        col = X(:,j);
        if any(isnan(col))
            m = median(col,'omitnan'); if ~isfinite(m), m = 0; end
            col(isnan(col)) = m; X(:,j) = col;
        end
    end
end

function [Xn, normp] = minmax_fit_transform(X)
    X = double(X);
    mn = min(X,[],1); mx = max(X,[],1);
    rngv = mx - mn; rngv(rngv==0) = 1;
    Xn = (X - mn) ./ rngv;
    normp.min = mn; normp.max = mx; normp.range = rngv;
end

function Xn = minmax_apply(X, normp)
    Xn = (double(X) - normp.min) ./ normp.range;
end

function X = minmax_inverse(Xn, normp)
    X = Xn .* normp.range + normp.min;
end

function [R2,RMSE,MSE,MAE,SMAPE,AARE] = regression_metrics_plus(y,yhat,safe_eps)
    y = y(:); yhat = yhat(:);
    ok = isfinite(y) & isfinite(yhat);
    y = y(ok); yhat = yhat(ok);
    err = y - yhat;
    MSE = mean(err.^2); RMSE = sqrt(MSE); MAE = mean(abs(err));
    denom = sum((y-mean(y)).^2);
    if numel(y) >= 2 && denom > 0
        R2 = 1 - sum(err.^2)/denom;
    else
        R2 = NaN;                      % undefined (single point / constant y)
    end
    SMAPE = mean(200*abs(err)./(abs(y)+abs(yhat)+safe_eps));
    AARE  = mean(100*abs(err)./max(abs(y),safe_eps));
end

function [tab, ax] = local_newTabAx(tg, tabName)
    tab = uitab(tg, 'Title', tabName);
    ax  = axes('Parent', tab);
    set(ax,'FontName','Times New Roman','FontSize',12,'Box','on','LineWidth',1, ...
        'XColor','k','YColor','k','Color','w');
end