"""
Shared framework for leave-one-MOF-out (LOMO) grouped CV, used across
all Python model scripts (XGBoost, RF, DT, ...). Import this rather
than duplicating the LOMO loop in every model script.
"""

import numpy as np
import pandas as pd


def regression_metrics(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    err = y_true - y_pred
    mse = np.mean(err ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(err))
    denom = np.sum((y_true - y_true.mean()) ** 2)
    r2 = 1 - np.sum(err ** 2) / denom if denom > 0 else np.nan
    aare = 100 * np.mean(np.abs(err) / np.maximum(np.abs(y_true), 1e-12))
    return r2, rmse, mae, aare


def load_dataset(file_path, target, group_col, likely_numeric_cols, cat_missing_label="Missing"):
    """Loads the dataset, coercing intended-numeric columns explicitly
    (catches e.g. a single stray non-numeric cell that would otherwise
    force an entire column to be read as text and silently one-hot
    encoded).

    cat_missing_label: categorical NaNs are filled with this literal
    string BEFORE one-hot encoding, so a missing category gets its own
    explicit dummy column (e.g. 'Topology__Missing') rather than
    resulting in an all-zero row across every dummy for that variable.
    This matches your MATLAB pipeline's behavior, where
    categorical(string(NaN)) produces a literal "NaN" category with its
    own column -- i.e. the model has an explicit signal for "topology
    unknown" rather than no signal at all. Set to None to instead leave
    missing rows as all-zero (pandas' default get_dummies behavior).
    """
    df = pd.read_excel(file_path)
    df.columns = [c.strip() for c in df.columns]
    df = df.dropna(subset=[target]).reset_index(drop=True)

    y = df[target].values
    groups = df[group_col].astype(str).values
    X_raw = df.drop(columns=[target, group_col])

    for col in likely_numeric_cols:
        if col in X_raw.columns and X_raw[col].dtype == object:
            coerced = pd.to_numeric(X_raw[col], errors="coerce")
            n_bad = coerced.isna().sum() - X_raw[col].isna().sum()
            if n_bad > 0:
                print(f"WARNING: column '{col}' had {n_bad} non-numeric entries; coercing to NaN.")
            X_raw[col] = coerced

    cat_cols = X_raw.select_dtypes(include=["object"]).columns.tolist()
    num_cols = [c for c in X_raw.columns if c not in cat_cols]

    if cat_missing_label is not None:
        for col in cat_cols:
            n_missing = X_raw[col].isna().sum()
            if n_missing > 0:
                print(f"NOTE: column '{col}' had {n_missing} missing values; "
                      f"filled with explicit '{cat_missing_label}' category (matches MATLAB behavior).")
                X_raw[col] = X_raw[col].fillna(cat_missing_label)

    return X_raw, y, groups, cat_cols, num_cols


def encode_fold_onehot(X_train_raw, X_test_raw, cat_cols, num_cols):
    """One-hot encode using TRAIN categories as the reference column set.
    Test data is reindexed to match exactly -- eliminates the
    shape-mismatch crash class seen in the MATLAB pipeline entirely."""
    X_train_cat = pd.get_dummies(X_train_raw[cat_cols], prefix_sep="__") if cat_cols else pd.DataFrame(index=X_train_raw.index)
    X_test_cat = pd.get_dummies(X_test_raw[cat_cols], prefix_sep="__") if cat_cols else pd.DataFrame(index=X_test_raw.index)
    X_test_cat = X_test_cat.reindex(columns=X_train_cat.columns, fill_value=0)

    X_train_enc = pd.concat([X_train_raw[num_cols].reset_index(drop=True), X_train_cat.reset_index(drop=True)], axis=1)
    X_test_enc = pd.concat([X_test_raw[num_cols].reset_index(drop=True), X_test_cat.reset_index(drop=True)], axis=1)
    return X_train_enc, X_test_enc


def run_random_split(X_raw, y, model_factory, cat_cols, num_cols, test_ratio=0.20, seed=42,
                      encode_fn=encode_fold_onehot):
    """Single random 80/20 split evaluation -- mirrors your MATLAB
    'Table 3' protocol (trainSummary / testSummary / allSummary). This
    is the INTERPOLATION baseline, kept separate from the LOMO
    generalization evaluation in run_lomo() below."""
    n = len(y)
    rng = np.random.RandomState(seed)
    idx = rng.permutation(n)
    n_test = round(test_ratio * n)
    test_idx = idx[:n_test]
    train_idx = idx[n_test:]

    X_train_raw = X_raw.iloc[train_idx]
    X_test_raw = X_raw.iloc[test_idx]
    y_train, y_test = y[train_idx], y[test_idx]

    X_train_enc, X_test_enc = encode_fn(X_train_raw, X_test_raw, cat_cols, num_cols)

    model = model_factory()
    model.fit(X_train_enc, y_train)

    y_pred_train = model.predict(X_train_enc)
    y_pred_test = model.predict(X_test_enc)
    y_all_true = np.concatenate([y_train, y_test])
    y_all_pred = np.concatenate([y_pred_train, y_pred_test])

    train_metrics = regression_metrics(y_train, y_pred_train)
    test_metrics = regression_metrics(y_test, y_pred_test)
    all_metrics = regression_metrics(y_all_true, y_all_pred)

    names = ["R2", "RMSE", "MAE", "AARE_pct"]
    return dict(
        train=dict(zip(names, train_metrics)),
        test=dict(zip(names, test_metrics)),
        all=dict(zip(names, all_metrics)),
        model=model,
        train_idx=train_idx, test_idx=test_idx,
        X_train_enc=X_train_enc, X_test_enc=X_test_enc,
    )


def run_lomo(X_raw, y, groups, model_factory, cat_cols, num_cols,
             encode_fn=encode_fold_onehot, run_shap=False, shap_explainer_factory=None,
             verbose_every=10, checkpoint_path=None):
    """Generic leave-one-MOF-out CV loop.

    model_factory: callable() -> a fresh, unfitted model with .fit(X, y)
        and .predict(X) (any sklearn-compatible regressor).
    shap_explainer_factory: callable(fitted_model) -> a SHAP explainer
        (e.g. shap.TreeExplainer for tree models, shap.KernelExplainer
        or shap.Explainer for others). Only used if run_shap=True.
    checkpoint_path: if given, the per-fold results table is saved to
        this Excel path after EVERY fold, so a crash partway through a
        long run (e.g. an ANN hitting a NaN loss on one hyperparameter
        combination) never loses already-completed folds. Strongly
        recommended for any model where a single fold could plausibly
        fail (ANN, CSA-LSSVM) -- optional for fast, reliable models
        (tree ensembles) where it matters less.

    A single fold failing (exception during fit/predict) is caught,
    logged with NaN metrics and the error message, and the loop
    continues to the next fold rather than losing the whole run.
    """
    unique_mofs = np.unique(groups)
    n_mofs = len(unique_mofs)

    fold_results = []
    y_true_pooled, y_pred_pooled = [], []
    fold_id_pooled = []
    feat_shap_totals = {}
    total_explained_rows = 0

    for i, mof in enumerate(unique_mofs, 1):
        test_mask = groups == mof
        train_mask = ~test_mask

        try:
            X_train_raw = X_raw.loc[train_mask]
            X_test_raw = X_raw.loc[test_mask]
            y_train = y[train_mask]
            y_test = y[test_mask]

            X_train_enc, X_test_enc = encode_fn(X_train_raw, X_test_raw, cat_cols, num_cols)

            model = model_factory()
            model.fit(X_train_enc, y_train)
            y_pred = model.predict(X_test_enc)

            r2, rmse, mae, aare = regression_metrics(y_test, y_pred)
            fold_results.append({"MOF": mof, "n_test": int(test_mask.sum()), "R2": r2, "RMSE": rmse,
                                  "MAE": mae, "AARE_pct": aare, "Error": None})

            y_true_pooled.extend(np.asarray(y_test).tolist())
            y_pred_pooled.extend(np.asarray(y_pred).tolist())
            fold_id_pooled.extend([mof] * int(test_mask.sum()))

            if run_shap and shap_explainer_factory is not None:
                explainer = shap_explainer_factory(model)
                shap_values = explainer.shap_values(X_test_enc)
                mean_abs_shap = np.mean(np.abs(shap_values), axis=0)
                for col, val in zip(X_train_enc.columns, mean_abs_shap):
                    orig_var = col.split("__")[0] if "__" in col else col
                    feat_shap_totals[orig_var] = feat_shap_totals.get(orig_var, 0) + val * test_mask.sum()
                total_explained_rows += test_mask.sum()

            if i % verbose_every == 0 or i == n_mofs:
                print(f"Fold {i}/{n_mofs} done (held out: {mof}, n={test_mask.sum()}) R2={r2:.4f}")

        except Exception as e:
            fold_results.append({"MOF": mof, "n_test": int(test_mask.sum()), "R2": np.nan, "RMSE": np.nan,
                                  "MAE": np.nan, "AARE_pct": np.nan, "Error": str(e)})
            print(f"Fold {i}/{n_mofs} FAILED (held out: {mof}): {e}")

        if checkpoint_path is not None:
            try:
                pd.DataFrame(fold_results).to_excel(checkpoint_path, index=False)
            except Exception:
                pass  # don't let a file-write hiccup (e.g. file open elsewhere) stop the loop

    fold_df = pd.DataFrame(fold_results)
    n_failed = fold_df["Error"].notna().sum()
    if n_failed > 0:
        print(f"\n*** {n_failed} of {n_mofs} folds failed and were skipped (see 'Error' column) ***")

    r2_p, rmse_p, mae_p, aare_p = regression_metrics(y_true_pooled, y_pred_pooled)

    shap_ranking = None
    if run_shap and total_explained_rows > 0:
        shap_ranking = pd.DataFrame(
            [{"Feature": k, "MeanAbsSHAP": v / total_explained_rows} for k, v in feat_shap_totals.items()]
        ).sort_values("MeanAbsSHAP", ascending=False).reset_index(drop=True)
        shap_ranking["Rank"] = shap_ranking.index + 1

    return dict(R2_pooled=r2_p, RMSE_pooled=rmse_p, MAE_pooled=mae_p, AARE_pooled=aare_p,
                n_pooled=len(y_true_pooled), fold_df=fold_df, shap_ranking=shap_ranking,
                y_true_pooled=y_true_pooled, y_pred_pooled=y_pred_pooled, fold_id_pooled=fold_id_pooled)