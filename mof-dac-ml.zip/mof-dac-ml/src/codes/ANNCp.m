%% ============================================================
%  ANN -- Cp as TARGET -- v2 (Oct 2026)
%
%  Changes from the previous Cp script:
%   1. MOF_ID and CO2uptake are REMOVED from the inputs (the previous run
%      had both as inputs: framework-identity leak + other-target leak).
%   2. Same 80/20 split as the four Python Cp models (read from
%      Cp_split_indices.csv), with a check that the rows match.
%   3. LOMO (leave-one-MOF-out) section added, same protocol as the
%      CO2 ann01.m: early stopping on a 15% validation split taken from
%      the training MOFs only; the held-out MOF is never used for training.
%   4. Every prediction is saved (CSV), single-point LOMO folds report
%      R2 = NaN, and all files are prefixed ANN_Cp_ so they cannot
%      overwrite the CO2 results.
%   5. Local functions are at the end of the file (MATLAB requirement).
%
%  Files needed in the same folder:
%     MLDAC01.xlsx
%     Cp_split_indices.csv   (row_index, MOF, set, y_true -- same split as the Python Cp models)
%% ============================================================

set(0, 'DefaultFigureWindowStyle', 'docked');
clear; clc; close all;

%% ---------------- SAVE DIRECTORY (SCRIPT LOCATION) ----------------
scriptFullPath = mfilename('fullpath');
[saveDir,~,~] = fileparts(scriptFullPath);
if isempty(saveDir), saveDir = pwd; end
fprintf("All results will be saved to:\n%s\n", saveDir);

%% ---------------- SETTINGS ----------------
filePath   = "MLDAC01.xlsx";
targetName = "Cp";
groupCol   = "MOF_ID";
dropInputs = ["MOF_ID", "CO2uptake"];   % never used as inputs
splitFile  = "Cp_split_indices.csv";
checkFile  = "Cp_split_indices.csv";       % same file: its y_true column is used for the row-order check
outPrefix  = "ANN_Cp_";
rng(42);

Kfold    = 3;
nRepeats = 1;

saveTablesToExcel = true;
saveFigures       = true;
runLOMO           = true;

%% ---------------- ANN TRAINING SETTINGS (fixed) ----------------
maxEpochs       = 250;
miniBatchSize   = 64;
learnRate       = 1e-3;
valPatience     = 15;   % early stopping patience (epochs)

%% ---------------- HYPERPARAM GRID ----------------
layersGrid  = 1:20;
neuronsGrid = [2 4 8 16 32 64 100 128];

%% ---------------- LOAD DATA ----------------
T = readtable(filePath, "PreserveVariableNames", true);
if ~ismember(targetName, string(T.Properties.VariableNames))
    error("Target column '%s' not found.", targetName);
end
if ~ismember(groupCol, string(T.Properties.VariableNames))
    error("Grouping column '%s' not found.", groupCol);
end

% Remove rows with missing target only (same rule as the Python scripts)
T = T(~ismissing(T.(targetName)), :);

yAll   = double(T.(targetName));
groups = string(T.(groupCol));

% Inputs: everything except the target, MOF_ID and CO2uptake
Xraw = removevars(T, targetName);
dropCols = intersect(dropInputs, string(Xraw.Properties.VariableNames));
Xraw = removevars(Xraw, dropCols);
assert(~any(ismember(dropInputs, string(Xraw.Properties.VariableNames))), ...
    "Leak columns (MOF_ID / CO2uptake) are still in the inputs.");

% Convert string/char/cellstr predictors to categorical
for j = 1:width(Xraw)
    v = Xraw.(j);
    if isstring(v) || ischar(v) || iscellstr(v)
        Xraw.(j) = categorical(string(v));
    end
end

yAll = yAll(:);
assert(all(isfinite(yAll)), "Non-finite Cp values found; the row order would no longer match Python.");

n = height(Xraw);
fprintf("Target: %s | %d rows across %d MOFs | inputs: %s\n", targetName, n, numel(unique(groups)), ...
    strjoin(string(Xraw.Properties.VariableNames), ", "));

%% ---------------- TRAIN/TEST SPLIT (same as Python Cp models) ----------------
S = readtable(splitFile, "TextType", "string");
testIdx  = S.row_index(S.set == "test")  + 1;   % Python is 0-based
trainIdx = S.row_index(S.set == "train") + 1;
assert(numel(testIdx) + numel(trainIdx) == n, ...
    "Split file has %d rows but MATLAB loaded %d rows.", numel(testIdx) + numel(trainIdx), n);

% Row-order check: Cp values at these rows must equal Python's y_true
P = readtable(checkFile, "TextType", "string");
assert(max(abs(yAll(P.row_index + 1) - P.y_true)) < 1e-9, ...
    "Row order differs from the Python run; do not use these results.");
fprintf("Split check passed: train=%d | test=%d (same rows as the Python Cp models)\n", ...
    numel(trainIdx), numel(testIdx));

Xtrain_raw = Xraw(trainIdx,:);
ytrain     = yAll(trainIdx);
Xtest_raw  = Xraw(testIdx,:);
ytest      = yAll(testIdx);

%% ============================================================
%  GRID SEARCH with K-fold CV (training split only)
%% ============================================================
comb = makeGrid_ANN(layersGrid, neuronsGrid);
nComb = height(comb);

R2_mean   = nan(nComb,1);
RMSE_mean = nan(nComb,1);
MAE_mean  = nan(nComb,1);
AARE_mean = nan(nComb,1);

fprintf("\n=== ANN hyperparameter search (%d combos) ===\n", nComb);
t0 = tic;
for c = 1:nComb
    hp = comb(c,:);
    [r2v, rmsev, maev, aarev] = repeatedCV_ANN(Xtrain_raw, ytrain, Kfold, nRepeats, hp, ...
        maxEpochs, miniBatchSize, learnRate, valPatience);
    R2_mean(c)   = mean(r2v,   'omitnan');
    RMSE_mean(c) = mean(rmsev, 'omitnan');
    MAE_mean(c)  = mean(maev,  'omitnan');
    AARE_mean(c) = mean(aarev, 'omitnan');
    if mod(c, max(1,floor(nComb/10)))==0 || c==nComb
        fprintf("Progress: %d/%d (elapsed %.1fs)\n", c, nComb, toc(t0));
    end
end

results = comb;
results.R2_mean   = R2_mean;
results.RMSE_mean = RMSE_mean;
results.MAE_mean  = MAE_mean;
results.AARE_mean = AARE_mean;
results = results(~isnan(results.R2_mean),:);
results = sortrows(results, ["R2_mean","RMSE_mean"], ["descend","ascend"]);

disp("Top 5 (CV):");
disp(results(1:min(5,height(results)),:));
best = results(1,:);

if saveTablesToExcel
    writetable(results, fullfile(saveDir, outPrefix + "hyperparameter_search.xlsx"));
end

%% ============================================================
%  TRAIN BEST MODEL on ALL TRAIN and evaluate on HOLD-OUT TEST
%% ============================================================
fprintf("\n=== Training BEST ANN on full training split ===\n");
disp(best);

[Xtr, featNames] = onehot_from_train(Xtrain_raw);
Xte              = onehot_apply_test(Xtest_raw, Xtrain_raw, featNames);
assert(~any(startsWith(featNames, "MOF_ID") | featNames == "CO2uptake"), "Leak feature in encoded inputs.");
fprintf("Encoded features: %d\n", numel(featNames));

[Xtr, ytrain] = make_finite_pair(Xtr, ytrain);
[Xte, ytest ] = make_finite_pair(Xte, ytest);

[XtrS, scalerX] = minmax_fit_transform(Xtr);
XteS            = minmax_apply(Xte, scalerX);
[ytrS, scalerY] = minmax_fit_transform(ytrain);

netLayers = build_regression_mlp(size(XtrS,2), best.NumHiddenLayers, best.NeuronsPerLayer);
opts = trainingOptions("adam", ...
    MaxEpochs=maxEpochs, ...
    MiniBatchSize=miniBatchSize, ...
    InitialLearnRate=learnRate, ...
    Shuffle="every-epoch", ...
    Verbose=false);
net = trainNetwork(XtrS, ytrS, netLayers, opts);

yPred_te = minmax_reverse(predict(net, XteS), scalerY);
yPred_tr = minmax_reverse(predict(net, XtrS), scalerY);
yall      = [ytrain; ytest];
yPred_all = [yPred_tr; yPred_te];

[R2tr, RMSEtr, MSEtr, MAEtr, SMAPEtr, AAREtr]       = regression_metrics_plus(ytrain, yPred_tr);
[R2t,  RMSEt,  MSEt,  MAEt,  SMAPEt,  AAREt]        = regression_metrics_plus(ytest,  yPred_te);
[R2all, RMSEall, MSEall, MAEall, SMAPEall, AAREall] = regression_metrics_plus(yall,   yPred_all);

perfTbl = table(["Train"; "Test"; "All"], [numel(ytrain); numel(ytest); numel(yall)], ...
    [R2tr; R2t; R2all], [MSEtr; MSEt; MSEall], [RMSEtr; RMSEt; RMSEall], ...
    [MAEtr; MAEt; MAEall], [SMAPEtr; SMAPEt; SMAPEall], [AAREtr; AAREt; AAREall], ...
    'VariableNames', {'Set','N','R2','MSE','RMSE','MAE','SMAPE_percent','AARE_percent'});
disp("===== RANDOM-SPLIT PERFORMANCE (Best ANN, Cp) =====");
disp(perfTbl);

if saveTablesToExcel
    writetable(perfTbl, fullfile(saveDir, outPrefix + "RandomSplit_performance.xlsx"));
    writetable(table(string(featNames(:)), 'VariableNames', {'Feature'}), ...
        fullfile(saveDir, outPrefix + "feature_names.xlsx"));
    predTbl = table([trainIdx(:); testIdx(:)] - 1, [groups(trainIdx); groups(testIdx)], ...
        [repmat("train", numel(trainIdx), 1); repmat("test", numel(testIdx), 1)], ...
        yall, yPred_all, 'VariableNames', {'row_index','MOF','set','y_true','y_pred'});
    writetable(predTbl, fullfile(saveDir, outPrefix + "predictions_randomsplit.csv"));
end

%% ============================================================
%  LOMO (leave-one-MOF-out) with the same best hyperparameters
%% ============================================================
if runLOMO
    uniqueGroups = unique(groups);
    nF = numel(uniqueGroups);
    fprintf("\n=== LOMO: %d folds, layers=%d, neurons=%d ===\n", nF, best.NumHiddenLayers, best.NeuronsPerLayer);

    foldR2 = nan(nF,1); foldRMSE = nan(nF,1); foldMAE = nan(nF,1); foldAARE = nan(nF,1);
    foldN = zeros(nF,1); foldErr = strings(nF,1);
    yT_pool = []; yP_pool = []; g_pool = strings(0,1);

    for f = 1:nF
        teMask = (groups == uniqueGroups(f));
        trMask = ~teMask;
        foldN(f) = sum(teMask);
        try
            [net_f, featNames_f, scalerX_f, scalerY_f] = train_ann_lomo_internal_val( ...
                Xraw(trMask,:), yAll(trMask), best.NumHiddenLayers, best.NeuronsPerLayer, ...
                maxEpochs, miniBatchSize, learnRate, valPatience);
            Xte_f = onehot_apply_test(Xraw(teMask,:), Xraw(trMask,:), featNames_f);
            yte_f = yAll(teMask);
            [Xte_f, yte_f] = make_finite_pair(Xte_f, yte_f);
            yP_f = minmax_reverse(predict(net_f, minmax_apply(Xte_f, scalerX_f)), scalerY_f);

            [r2_f, rmse_f, ~, mae_f, ~, aare_f] = regression_metrics_plus(yte_f, yP_f);
            if numel(yte_f) < 2, r2_f = NaN; end   % R2 undefined for one point
            foldR2(f) = r2_f; foldRMSE(f) = rmse_f; foldMAE(f) = mae_f; foldAARE(f) = aare_f;

            yT_pool = [yT_pool; yte_f(:)];                       %#ok<AGROW>
            yP_pool = [yP_pool; yP_f(:)];                         %#ok<AGROW>
            g_pool  = [g_pool; repmat(uniqueGroups(f), numel(yte_f), 1)]; %#ok<AGROW>
            fprintf("  Fold %d/%d | %s | n=%d | R2=%.4f\n", f, nF, uniqueGroups(f), foldN(f), r2_f);
        catch ME
            foldErr(f) = string(ME.message);
            fprintf("  Fold %d/%d | %s | FAILED: %s\n", f, nF, uniqueGroups(f), ME.message);
        end
        foldTbl = table((1:nF)', uniqueGroups, foldN, foldR2, foldRMSE, foldMAE, foldAARE, foldErr, ...
            'VariableNames', {'Fold','MOF','n_test','R2','RMSE','MAE','AARE_pct','Error'});
        try, writetable(foldTbl, fullfile(saveDir, outPrefix + "LOMO_checkpoint.xlsx")); catch, end
    end

    [R2p, RMSEp, MSEp, MAEp, ~, AAREp] = regression_metrics_plus(yT_pool, yP_pool);
    pooledTbl = table(R2p, MSEp, RMSEp, MAEp, AAREp, numel(yT_pool), nF, sum(foldErr ~= ""), ...
        'VariableNames', {'R2_pooled','MSE_pooled','RMSE_pooled','MAE_pooled','AARE_pooled','N_pooled','N_MOFs','Failed_folds'});
    disp("===== LOMO POOLED (ANN, Cp) =====");
    disp(pooledTbl);

    if saveTablesToExcel
        writetable(foldTbl,   fullfile(saveDir, outPrefix + "LOMO_perfold.xlsx"));
        writetable(pooledTbl, fullfile(saveDir, outPrefix + "LOMO_POOLED_summary.xlsx"));
        writetable(table(g_pool, yT_pool, yP_pool, 'VariableNames', {'MOF','y_true','y_pred'}), ...
            fullfile(saveDir, outPrefix + "predictions_LOMO.csv"));
    end
end

%% ============================================================
%  PLOTS
%% ============================================================
fig1 = figure('Name','ANN Cp Predicted vs Reference (Train + Test)', 'Position',[100 100 800 700], 'Color','white');
ax = gca; set(ax,'FontName','Times New Roman','FontSize',12,'XColor','k','YColor','k','LineWidth',1.2,'Box','on');
hold on; grid on;
scatter(ytrain, yPred_tr, 55, 'MarkerFaceColor',[0 0.6 0.6], 'MarkerEdgeColor','k');
scatter(ytest,  yPred_te, 55, 'MarkerFaceColor',[0 0 0.8],   'MarkerEdgeColor','k');
mn = min([yall; yPred_all]); mx = max([yall; yPred_all]);
plot([mn mx],[mn mx],'k-','LineWidth',1.8);
text(0.05,0.92, sprintf('R^2_{Train}=%.4f\nR^2_{Test}=%.4f\nRMSE_{Test}=%.4f', R2tr, R2t, RMSEt), ...
     'Units','normalized','FontName','Times New Roman','FontSize',12,'BackgroundColor','white','EdgeColor','k');
xlabel('Reference C_p (J g^{-1} K^{-1})','FontName','Times New Roman','FontSize',12);
ylabel('Predicted C_p (J g^{-1} K^{-1})','FontName','Times New Roman','FontSize',12);
legend({'Train','Test','y = x'},'Location','northwest','FontName','Times New Roman','FontSize',12);
axis equal; axis tight;

if saveFigures
    saveas(fig1, fullfile(saveDir, outPrefix + "scatter_train_test.png"));
    saveas(fig1, fullfile(saveDir, outPrefix + "scatter_train_test.fig"));
end

fprintf("\n=== ANN Cp v2 complete ===\n");

%% ============================================================
%  LOCAL FUNCTIONS (must stay at the end of the script)
%% ============================================================
function [net, featNames, scalerX, scalerY] = train_ann_lomo_internal_val( ...
        Xtr_raw, ytr, nHidden, nNeurons, maxEpochs, miniBatchSize, learnRate, valPatience)
    % Early-stopping validation split is taken from the TRAINING MOFs only.
    [Xtr, featNames] = onehot_from_train(Xtr_raw);
    [Xtr, ytr] = make_finite_pair(Xtr, ytr);
    n = size(Xtr,1);
    rng(123);
    permIdx = randperm(n);
    nVal = max(1, round(0.15*n));
    valIdx = permIdx(1:nVal);
    fitIdx = permIdx(nVal+1:end);

    [XfitS, scalerX] = minmax_fit_transform(Xtr(fitIdx,:));
    XvalS = minmax_apply(Xtr(valIdx,:), scalerX);
    [yfitS, scalerY] = minmax_fit_transform(ytr(fitIdx));
    yvalS = minmax_apply(ytr(valIdx), scalerY);

    layers = build_regression_mlp(size(XfitS,2), nHidden, nNeurons);
    opts = trainingOptions("adam", ...
        MaxEpochs=maxEpochs, ...
        MiniBatchSize=miniBatchSize, ...
        InitialLearnRate=learnRate, ...
        Shuffle="every-epoch", ...
        ValidationData={XvalS, yvalS}, ...
        ValidationPatience=valPatience, ...
        Verbose=false);
    net = trainNetwork(XfitS, yfitS, layers, opts);
end

function comb = makeGrid_ANN(layersGrid, neuronsGrid)
    [A,B] = ndgrid(layersGrid, neuronsGrid);
    comb = table;
    comb.NumHiddenLayers  = A(:);
    comb.NeuronsPerLayer  = B(:);
end

function [R2rep, RMSErep, MAErep, AARErep] = repeatedCV_ANN(Xraw, y, K, nRepeats, hp, ...
    maxEpochs, miniBatchSize, learnRate, valPatience)
    n = numel(y);
    R2rep = nan(nRepeats,1); RMSErep = nan(nRepeats,1); MAErep = nan(nRepeats,1); AARErep = nan(nRepeats,1);
    for r = 1:nRepeats
        rng(1000+r);
        cvp = cvpartition(n, "KFold", K);
        yhatAll = nan(n,1);
        for k = 1:K
            tr = training(cvp,k);
            va = test(cvp,k);
            [Xtr, featNames] = onehot_from_train(Xraw(tr,:));
            Xva              = onehot_apply_test(Xraw(va,:), Xraw(tr,:), featNames);
            ytr = y(tr); yva = y(va);
            [Xtr, ytr] = make_finite_pair(Xtr, ytr);
            [Xva, yva] = make_finite_pair(Xva, yva);
            [XtrS, scalerX] = minmax_fit_transform(Xtr);
            XvaS            = minmax_apply(Xva, scalerX);
            [ytrS, scalerY] = minmax_fit_transform(ytr);
            yvaS            = minmax_apply(yva, scalerY);
            layers = build_regression_mlp(size(XtrS,2), hp.NumHiddenLayers, hp.NeuronsPerLayer);
            opts = trainingOptions("adam", ...
                MaxEpochs=maxEpochs, ...
                MiniBatchSize=miniBatchSize, ...
                InitialLearnRate=learnRate, ...
                Shuffle="every-epoch", ...
                ValidationData={XvaS, yvaS}, ...
                ValidationPatience=valPatience, ...
                Verbose=false);
            try
                net = trainNetwork(XtrS, ytrS, layers, opts);
                ypred_va = minmax_reverse(predict(net, XvaS), scalerY);
            catch
                ypred_va = mean(ytr) * ones(size(yva));
            end
            yhatAll(va) = ypred_va(:);
        end
        [R2rep(r), RMSErep(r), ~, MAErep(r), ~, AARErep(r)] = regression_metrics_plus(y, yhatAll);
    end
end

function layers = build_regression_mlp(inputDim, nHidden, nNeurons)
    layers = [featureInputLayer(inputDim, 'Name','in')];
    for i = 1:nHidden
        layers = [layers
            fullyConnectedLayer(nNeurons, 'Name', sprintf('fc%d',i))
            reluLayer('Name', sprintf('relu%d',i))]; %#ok<AGROW>
    end
    layers = [layers
        fullyConnectedLayer(1, 'Name','out')
        regressionLayer('Name','reg')];
end

function [X, y] = make_finite_pair(X, y)
    X(~isfinite(X)) = NaN;
    y(~isfinite(y)) = NaN;
    bad = isnan(y);
    if any(bad)
        X(bad,:) = [];
        y(bad,:) = [];
    end
    if any(isnan(X), 'all')
        for j = 1:size(X,2)
            col = X(:,j);
            m = median(col,'omitnan');
            if ~isfinite(m), m = 0; end
            col(isnan(col)) = m;
            X(:,j) = col;
        end
    end
    if any(~isfinite(X),'all') || any(~isfinite(y),'all')
        error("Non-finite remained after cleaning.");
    end
end

function [Xscaled, scaler] = minmax_fit_transform(X)
    xmin = min(X,[],1);
    xmax = max(X,[],1);
    rngv = xmax - xmin;
    rngv(rngv==0) = 1;
    Xscaled = (X - xmin) ./ rngv;
    scaler.xmin = xmin;
    scaler.rng  = rngv;
end

function Xscaled = minmax_apply(X, scaler)
    Xscaled = (X - scaler.xmin) ./ scaler.rng;
end

function X = minmax_reverse(Xscaled, scaler)
    X = Xscaled .* scaler.rng + scaler.xmin;
end

function [R2, RMSE, MSE, MAE, SMAPE, AARE] = regression_metrics_plus(y, yhat)
    y = y(:); yhat = yhat(:);
    ok = ~(isnan(y) | isnan(yhat) | isinf(y) | isinf(yhat));
    y = y(ok); yhat = yhat(ok);
    err = y - yhat;
    MSE  = mean(err.^2);
    RMSE = sqrt(MSE);
    MAE  = mean(abs(err));
    denom = sum((y - mean(y)).^2);
    if denom > 0
        R2 = 1 - sum(err.^2) / denom;
    else
        R2 = NaN;                       % undefined (single point / constant y)
    end
    eps0  = 1e-12;
    SMAPE = mean(200*abs(err) ./ (abs(y)+abs(yhat)+eps0));
    AARE  = mean(100*abs(err) ./ max(abs(y), eps0));
end

function [Xmat, featNames] = onehot_from_train(Xtrain)
    varNames = string(Xtrain.Properties.VariableNames);
    isCat = false(1, width(Xtrain));
    for j = 1:width(Xtrain)
        isCat(j) = iscategorical(Xtrain.(j));
    end
    numVars = varNames(~isCat);
    Xnum = [];
    numNames = strings(1,0);
    for j = 1:numel(numVars)
        Xnum = [Xnum, double(Xtrain.(numVars(j)))]; %#ok<AGROW>
        numNames(end+1) = numVars(j); %#ok<AGROW>
    end
    catVars = varNames(isCat);
    Xcat = [];
    catNames = strings(1,0);
    for j = 1:numel(catVars)
        v = Xtrain.(catVars(j));
        cats = categories(v);
        D = zeros(height(Xtrain), numel(cats));
        for c = 1:numel(cats)
            D(:,c) = double(v == cats{c});
            catNames(end+1) = catVars(j) + "__" + string(cats{c}); %#ok<AGROW>
        end
        Xcat = [Xcat, D]; %#ok<AGROW>
    end
    Xmat = [Xnum, Xcat];
    featNames = [numNames, catNames];
end

function XtestMat = onehot_apply_test(Xtest, Xtrain, featNames)
    varNamesTrain = string(Xtrain.Properties.VariableNames);
    isCatTrain = false(1, width(Xtrain));
    for j = 1:width(Xtrain)
        isCatTrain(j) = iscategorical(Xtrain.(j));
    end
    numVars = varNamesTrain(~isCatTrain);
    Xnum = [];
    for j = 1:numel(numVars)
        Xnum = [Xnum, double(Xtest.(numVars(j)))]; %#ok<AGROW>
    end
    catVars = varNamesTrain(isCatTrain);
    Xcat = [];
    for j = 1:numel(catVars)
        cats = categories(Xtrain.(catVars(j)));
        vTest = Xtest.(catVars(j));
        if ~iscategorical(vTest), vTest = categorical(string(vTest)); end
        D = zeros(height(Xtest), numel(cats));
        for c = 1:numel(cats)
            D(:,c) = double(vTest == cats{c});
        end
        Xcat = [Xcat, D]; %#ok<AGROW>
    end
    XtestMat = [Xnum, Xcat];
    if size(XtestMat,2) ~= numel(featNames)
        error("Encoded test feature count mismatch.");
    end
end