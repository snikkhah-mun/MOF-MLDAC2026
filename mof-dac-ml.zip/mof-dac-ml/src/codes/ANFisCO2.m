%% ============================================================
%  ANFIS Regression — K-Fold CV Grid Search (FASTER, NO validation split)
%  - Outer split: TrainAll vs Test (hold-out)
%  - Inner K-fold CV on TrainAll for hyperparameter selection
%  - One-hot encoder fit on fold-train only (NO leakage)
%  - Min-max scaling fit on fold-train only (NO leakage)
%  - Feature ranking computed on fold-train only (NO leakage)
%  - FAST improvements:
%      (1) parfor over grid combos (if Parallel Computing Toolbox exists)
%      (2) precomputed fold indices
%      (3) vectorized Spearman ranking via corr(X,y)
%      (4) fast one-hot encoding via dummyvar + preallocation
%      (5) optional: smaller GS_MaxEpoch for tuning
%  - Best config retrained on full TrainAll, evaluated on Test
%% ============================================================

set(0,'DefaultFigureWindowStyle','docked');
clear; clc; close all;

%% ---------------- USER SETTINGS ----------------
filePath   = "MLDAC01.xlsx";    % <-- your file
targetName = "CO2uptake";

testRatio  = 0.20;              % outer test split (hold-out)
Kfold      = 3;                 % inner CV folds (3 is faster; 5 more robust)

rng(42);

saveTablesToExcel = true;

%% Grid search (keep total combos reasonable)
search_Radius   = [0.30 0.40 0.50 0.60 0.70 0.80];
search_TopK     = [8 10 12 14 16 18 22];
search_StepSize = [0.005 0.01 0.02 0.03];

% --------- SPEED KNOB 1 (tuning epochs) ----------
% For grid search, you can usually use 30–80 epochs.
GS_MaxEpoch  = 60;     % was 200 in your version (this is a big speedup)
GS_ErrorGoal = 0;
GS_DecRate   = 0.9;
GS_IncRate   = 1.1;
GS_OptMethod = 1;      % 1 Hybrid 0 BP
FINAL_MaxEpoch = 800;  % final training epochs on full TrainAll

RANGE_MIN = 1e-6;

%% MF selection
mfTypeOptions = {'dsigmf','pimf','gaussmf','gbellmf','gauss2mf','psigmf','trapmf'};
[mfTypeIndex, ok] = listdlg('PromptString','Select MF Type:', ...
    'SelectionMode','single','ListString',mfTypeOptions);
if ~ok, error('MF selection canceled.'); end
mfType = mfTypeOptions{mfTypeIndex};
fprintf("Selected MF type: %s\n", mfType);

% used only if not gaussmf (genfis1)
numMFs_for_genfis1 = 2;

%% ============================================================
%  LOAD DATA
%% ============================================================
Traw = readtable(filePath,"PreserveVariableNames",true);

if ~ismember(targetName, string(Traw.Properties.VariableNames))
    error("Target '%s' not found in Excel headers.", targetName);
end

% Remove rows with missing target
Traw = Traw(~ismissing(Traw.(targetName)),:);

Y_all = Traw.(targetName);
Xtab  = removevars(Traw, targetName);

% Convert text-like columns to categorical
for j = 1:width(Xtab)
    v = Xtab.(j);
    if isstring(v) || ischar(v) || iscellstr(v)
        Xtab.(j) = categorical(string(v));
    end
end

N = height(Xtab);
fprintf("Total samples: %d\n", N);

%% ============================================================
%  OUTER SPLIT: TRAINALL / TEST
%% ============================================================
cvOuter = cvpartition(N,'HoldOut',testRatio);
idxTrainAll = training(cvOuter);
idxTest     = test(cvOuter);

X_trainTab_all = Xtab(idxTrainAll,:);
Y_train_all    = Y_all(idxTrainAll);

X_testTab      = Xtab(idxTest,:);
Y_test_raw     = Y_all(idxTest);

fprintf("TrainAll: %d | Test: %d\n", sum(idxTrainAll), sum(idxTest));

%% ============================================================
%  GRID SEARCH WITH K-FOLD CV (FASTER) on TrainAll only
%% ============================================================
nR  = numel(search_Radius);
nK  = numel(search_TopK);
nSS = numel(search_StepSize);
nTotal = nR*nK*nSS;

fprintf("\n=== K-FOLD CV GRID SEARCH (%d folds) ===\n", Kfold);
fprintf("Total combos: %d\n", nTotal);

% ---------- Build combo list once ----------
[RR, KK, SS] = ndgrid(search_Radius, search_TopK, search_StepSize);
combos = [RR(:), KK(:), SS(:)];   % nTotal x 3

Radius_arr = combos(:,1);
TopK_arr   = combos(:,2);
Step_arr   = combos(:,3);

% ---------- Precompute fold indices once ----------
cvInner = cvpartition(sum(idxTrainAll),'KFold',Kfold);
foldTr = cell(Kfold,1);
foldVl = cell(Kfold,1);
for f = 1:Kfold
    foldTr{f} = training(cvInner,f);
    foldVl{f} = test(cvInner,f);
end

% ---------- Preallocate arrays (parfor friendly) ----------
MeanR2_arr    = nan(nTotal,1);
StdR2_arr     = nan(nTotal,1);
MeanRMSE_arr  = nan(nTotal,1);
MeanMAE_arr   = nan(nTotal,1);
MeanSMAPE_arr = nan(nTotal,1);
RulesMean_arr = nan(nTotal,1);
ParamsMean_arr= nan(nTotal,1);

% ---------- Parallel if available ----------
useParallel = license('test','Distrib_Computing_Toolbox');
if useParallel
    if isempty(gcp('nocreate')), parpool; end
    fprintf("Parallel pool enabled.\n");
else
    fprintf("Parallel pool NOT available (running serial).\n");
end

if useParallel
    parfor c = 1:nTotal
        [MeanR2_arr(c), StdR2_arr(c), MeanRMSE_arr(c), MeanMAE_arr(c), MeanSMAPE_arr(c), ...
         RulesMean_arr(c), ParamsMean_arr(c)] = ...
            eval_one_combo_fast( ...
                Radius_arr(c), TopK_arr(c), Step_arr(c), ...
                X_trainTab_all, Y_train_all, foldTr, foldVl, Kfold, ...
                mfType, numMFs_for_genfis1, GS_MaxEpoch, GS_ErrorGoal, GS_DecRate, GS_IncRate, GS_OptMethod, RANGE_MIN);
    end
else
    for c = 1:nTotal
        fprintf("[%3d/%d] R=%.2f | TopK=%d | Step=%.4f ... ", c,nTotal,Radius_arr(c),TopK_arr(c),Step_arr(c));
        [MeanR2_arr(c), StdR2_arr(c), MeanRMSE_arr(c), MeanMAE_arr(c), MeanSMAPE_arr(c), ...
         RulesMean_arr(c), ParamsMean_arr(c)] = ...
            eval_one_combo_fast( ...
                Radius_arr(c), TopK_arr(c), Step_arr(c), ...
                X_trainTab_all, Y_train_all, foldTr, foldVl, Kfold, ...
                mfType, numMFs_for_genfis1, GS_MaxEpoch, GS_ErrorGoal, GS_DecRate, GS_IncRate, GS_OptMethod, RANGE_MIN);
        fprintf("MeanR2=%.4f (±%.4f)\n", MeanR2_arr(c), StdR2_arr(c));
    end
end

% ---------- Results table ----------
gsResults = table(Radius_arr, TopK_arr, Step_arr, MeanR2_arr, StdR2_arr, MeanRMSE_arr, MeanMAE_arr, MeanSMAPE_arr, RulesMean_arr, ParamsMean_arr, ...
    'VariableNames',{'Radius','TopK','StepSize','MeanR2_CV','StdR2_CV','MeanRMSE_CV','MeanMAE_CV','MeanSMAPE_CV','NumRules_mean','NumParams_mean'});

gsResults_sorted = sortrows(gsResults,'MeanR2_CV','descend','MissingPlacement','last');

best_params = struct('Radius', gsResults_sorted.Radius(1), ...
                     'TopK',   gsResults_sorted.TopK(1), ...
                     'StepSize', gsResults_sorted.StepSize(1));
bestScore = gsResults_sorted.MeanR2_CV(1);

fprintf("\n=== BEST (by Mean CV R2) ===\n");
fprintf("Radius=%.2f | TopK=%d | Step=%.4f | MeanCV R2=%.4f\n", ...
    best_params.Radius, best_params.TopK, best_params.StepSize, bestScore);

if saveTablesToExcel
    writetable(gsResults_sorted,"ANFIS_CV_grid_results.xlsx");
    fprintf("Saved: ANFIS_CV_grid_results.xlsx\n");
end

%% ============================================================
%  FINAL TRAINING on FULL TrainAll (best params), Evaluate on Test
%% ============================================================
fprintf("\n=== FINAL TRAIN on TrainAll, EVAL on Test ===\n");

% One-hot fit on TrainAll only
[XtrAll, encAll] = onehot_fit_transform_fast(X_trainTab_all);
XteAll = onehot_apply_fast(X_testTab, encAll);

% Clean
[XtrAll, Y_train_all] = make_finite_pair_numeric(XtrAll, Y_train_all);
[XteAll, Y_test_raw]  = make_finite_pair_numeric(XteAll, Y_test_raw);

% Normalize fit on TrainAll only
[XtrN, normXall] = minmax_fit_transform(XtrAll);
XteN = minmax_apply(XteAll, normXall);
XteN = min(max(XteN,0),1); % clamp numerical drift

[YtrN, normYall] = minmax_fit_transform(Y_train_all(:));
YteN = minmax_apply(Y_test_raw(:), normYall);

SAFE_EPS = max(0.01*median(abs(Y_train_all(:)),'omitnan'), 1e-6);

% Rank features on TrainAll only (vectorized Spearman)
rvec = corr(XtrN, YtrN(:), 'Type','Spearman', 'Rows','pairwise');
rvec(~isfinite(rvec)) = 0;
[~, order] = sort(abs(rvec),'descend');

k_use = min(best_params.TopK, numel(order));
selIdx = order(1:k_use);

TrIn = XtrN(:,selIdx);
TeIn = XteN(:,selIdx);

% Drop constant
cr = max(TrIn,[],1)-min(TrIn,[],1);
keep = cr>0;
TrIn = TrIn(:,keep);
TeIn = TeIn(:,keep);

% Build FIS
if strcmpi(mfType,'gaussmf')
    opt = genfisOptions('SubtractiveClustering','ClusterInfluenceRange',best_params.Radius);
    fis0 = genfis(TrIn, YtrN(:), opt);
else
    fis0 = genfis1([TrIn YtrN(:)], numMFs_for_genfis1, mfType);
end

% Clamp ranges
for ii=1:numel(fis0.Inputs)
    lo=fis0.Inputs(ii).Range(1); hi=fis0.Inputs(ii).Range(2);
    if hi-lo < RANGE_MIN
        mid=(lo+hi)/2;
        fis0.Inputs(ii).Range=[mid-RANGE_MIN/2, mid+RANGE_MIN/2];
    end
end

% Train final
TrainOptions = [FINAL_MaxEpoch,0,best_params.StepSize,GS_DecRate,GS_IncRate];
DisplayOn = [true true true true];

[fis_final,trErr,stepSize] = anfis([TrIn YtrN(:)], fis0, TrainOptions, DisplayOn, [], GS_OptMethod);

for ii=1:numel(fis_final.Inputs), fis_final.Inputs(ii).Range=[0,1]; end

% Predict
Ytr_hatN = evalfis(fis_final, TrIn);
Yte_hatN = evalfis(fis_final, TeIn);

Ytr_hat = minmax_inverse(Ytr_hatN, normYall);
Yte_hat = minmax_inverse(Yte_hatN, normYall);

% Metrics
[R2tr,RMSEtr,~,MAEtr,SMAPEtr,AAREtr] = regression_metrics_plus(Y_train_all(:), Ytr_hat, SAFE_EPS);
[R2te,RMSEte,~,MAEte,SMAPEte,AAREte] = regression_metrics_plus(Y_test_raw(:),  Yte_hat, SAFE_EPS);

fprintf("\nTRAIN: R2=%.4f | RMSE=%.4f | MAE=%.4f | SMAPE=%.2f | AARE=%.2f\n", ...
    R2tr,RMSEtr,MAEtr,SMAPEtr,AAREtr);
fprintf("TEST : R2=%.4f | RMSE=%.4f | MAE=%.4f | SMAPE=%.2f | AARE=%.2f\n", ...
    R2te,RMSEte,MAEte,SMAPEte,AAREte);
%% ============================================================
%  ADD MSE (Train/Test/All)
%% ============================================================

% MSE from RMSE (consistent with your metrics)
MSEtr  = RMSEtr^2;
MSEte  = RMSEte^2;

% All data (Train+Test)
Y_all_used    = [Y_train_all(:); Y_test_raw(:)];
Yhat_all_used = [Ytr_hat(:);     Yte_hat(:)];

% Compute ALL metrics again but keep MSE too
[ R2all, RMSEall, MSEall, MAEall, SMAPEall, AAREall ] = regression_metrics_plus( ...
    Y_all_used, Yhat_all_used, SAFE_EPS);

fprintf("\nTRAIN: R2=%.4f | RMSE=%.4f | MSE=%.4f | MAE=%.4f | SMAPE=%.2f | AARE=%.2f\n", ...
    R2tr, RMSEtr, MSEtr, MAEtr, SMAPEtr, AAREtr);

fprintf("TEST : R2=%.4f | RMSE=%.4f | MSE=%.4f | MAE=%.4f | SMAPE=%.2f | AARE=%.2f\n", ...
    R2te, RMSEte, MSEte, MAEte, SMAPEte, AAREte);

fprintf("ALL  : R2=%.4f | RMSE=%.4f | MSE=%.4f | MAE=%.4f | SMAPE=%.2f | AARE=%.2f\n", ...
    R2all, RMSEall, MSEall, MAEall, SMAPEall, AAREall);
%% ============================================================
%  OVERALL (ALL DATA) METRICS + TAB PLOTS
%% ============================================================

% --- Build ALL vectors (TrainAll + Test) ---
Y_all_used     = [Y_train_all(:); Y_test_raw(:)];
Yhat_all_used  = [Ytr_hat(:);     Yte_hat(:)];

% --- Metrics for ALL data ---
[R2all, RMSEall, ~, MAEall, SMAPEall, AAREall] = regression_metrics_plus( ...
    Y_all_used, Yhat_all_used, SAFE_EPS);

fprintf("\nALL  : R2=%.4f | RMSE=%.4f | MAE=%.4f | SMAPE=%.2f | AARE=%.2f\n", ...
    R2all, RMSEall, MAEall, SMAPEall, AAREall);

% --- Summary table (Train/Test/All) ---
perfTbl = table( ...
    ["TrainAll"; "Test"; "All"], ...
    [R2tr; R2te; R2all], ...
    [RMSEtr; RMSEte; RMSEall], ...
    [MSEtr;  MSEte;  MSEall], ...
    [MAEtr; MAEte; MAEall], ...
    [SMAPEtr; SMAPEte; SMAPEall], ...
    [AAREtr; AAREte; AAREall], ...
    'VariableNames', {'Split','R2','RMSE','MSE','MAE','SMAPE','AARE'} );

disp(perfTbl);

if saveTablesToExcel
    writetable(perfTbl, "ANFIS_Performance_Summary.xlsx");
    fprintf("Saved: ANFIS_Performance_Summary.xlsx\n");
end
savefig('figure.fig')
save('results.mat', 'Y_train', 'Y_test')
%% ---------------- Figure + tabs (use NORMAL; tabs don't like DOCKED) ----------------
set(0,'DefaultFigureWindowStyle','normal');

fig = figure('Name','ANFIS Scatter Plots','Color','w');
tg  = uitabgroup(fig);

% ========== TAB 1: TEST ==========
[~, ax] = local_newTabAx(tg, '1) Test: Pred vs Exp');

ytest  = Y_test_raw(:);
yhat_t = Yte_hat(:);

mn = min([ytest; yhat_t], [], 'omitnan');
mx = max([ytest; yhat_t], [], 'omitnan');

scatter(ax, ytest, yhat_t, 60, 'filled', 'MarkerFaceAlpha', 0.65);
hold(ax,'on'); grid(ax,'on');
plot(ax, [mn mx], [mn mx], 'k--', 'LineWidth', 2);

text(ax, 0.05, 0.95, sprintf('R^2 = %.4f\nRMSE = %.4f\nMAE = %.4f\nSMAPE = %.2f\nAARE = %.2f', ...
    R2te, RMSEte, MAEte, SMAPEte, AAREte), ...
    'Units','normalized', 'FontName','Times New Roman', 'FontSize',12, ...
    'FontWeight','bold', 'BackgroundColor','white', 'EdgeColor','black');

xlabel(ax,"Experimental CO_2 Uptake (mmol/g)", 'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
ylabel(ax,"Predicted CO_2 Uptake (mmol/g)",   'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
title(ax,"ANFIS: Predicted vs Experimental (Test)", 'FontName','Times New Roman','FontSize',14);

axis(ax,'equal'); axis(ax,'tight');

% ========== TAB 2: TRAIN ==========
[~, ax] = local_newTabAx(tg, '2) Train: Pred vs Exp');

ytr   = Y_train_all(:);
yhatR = Ytr_hat(:);

mn = min([ytr; yhatR], [], 'omitnan');
mx = max([ytr; yhatR], [], 'omitnan');

scatter(ax, ytr, yhatR, 60, 'filled', 'MarkerFaceAlpha', 0.60);
hold(ax,'on'); grid(ax,'on');
plot(ax, [mn mx], [mn mx], 'k--', 'LineWidth', 2);

text(ax, 0.05, 0.95, sprintf('R^2 = %.4f\nRMSE = %.4f\nMAE = %.4f\nSMAPE = %.2f\nAARE = %.2f', ...
    R2tr, RMSEtr, MAEtr, SMAPEtr, AAREtr), ...
    'Units','normalized', 'FontName','Times New Roman', 'FontSize',12, ...
    'FontWeight','bold', 'BackgroundColor','white', 'EdgeColor','black');

xlabel(ax,"Experimental CO_2 Uptake (mmol/g)", 'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
ylabel(ax,"Predicted CO_2 Uptake (mmol/g)",   'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
title(ax,"ANFIS: Predicted vs Experimental (TrainAll)", 'FontName','Times New Roman','FontSize',14);

axis(ax,'equal'); axis(ax,'tight');

% ========== TAB 3: TRAIN + TEST ==========
[~, ax] = local_newTabAx(tg, '3) Train + Test: Pred vs Exp');

mn = min([ytr; yhatR; ytest; yhat_t], [], 'omitnan');
mx = max([ytr; yhatR; ytest; yhat_t], [], 'omitnan');

hold(ax,'on'); grid(ax,'on');

% Train marker/color
s1 = scatter(ax, ytr, yhatR, 55, 'o', 'filled', 'MarkerFaceAlpha', 0.55);
% Test marker/color (different)
s2 = scatter(ax, ytest, yhat_t, 70, '^', 'filled', 'MarkerFaceAlpha', 0.75);

plot(ax, [mn mx], [mn mx], 'k--', 'LineWidth', 2);

legend(ax, [s1 s2], {'TrainAll','Test'}, 'Location','best', ...
    'FontName','Times New Roman','FontSize',12);

text(ax, 0.05, 0.95, sprintf(['ALL (Train+Test)\n' ...
                              'R^2 = %.4f\nRMSE = %.4f\nMAE = %.4f\nSMAPE = %.2f\nAARE = %.2f'], ...
                              R2all, RMSEall, MAEall, SMAPEall, AAREall), ...
    'Units','normalized', 'FontName','Times New Roman', 'FontSize',12, ...
    'FontWeight','bold', 'BackgroundColor','white', 'EdgeColor','black');

xlabel(ax,"Experimental CO_2 Uptake (mmol/g)", 'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
ylabel(ax,"Predicted CO_2 Uptake (mmol/g)",   'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
title(ax,"ANFIS: Predicted vs Experimental (Train + Test)", 'FontName','Times New Roman','FontSize',14);

axis(ax,'equal'); axis(ax,'tight');

%%
%% ---- 1. Training error curve + step size ----
figure('Name','Error Curves','Color','w');

ep_ax = 1:numel(trErr);

subplot(2,1,1);
plot(ep_ax, trErr, 'k-', 'LineWidth', 2);
grid on;
xlabel('Epoch','FontName','Times New Roman','FontSize',12,'FontWeight','bold');
ylabel('MSE (Training)','FontName','Times New Roman','FontSize',12,'FontWeight','bold');
title(sprintf('Training Error Curve | MF=%s | Epochs=%d', mfType, numel(trErr)), ...
    'Interpreter','none','FontName','Times New Roman','FontSize',12);
set(gca,'FontName','Times New Roman','FontSize',12,'Box','on','LineWidth',1,'XColor','k','YColor','k');

subplot(2,1,2);
plot(ep_ax, stepSize*ones(size(ep_ax)), 'k-', 'LineWidth', 2); % if stepSize is scalar
grid on;
xlabel('Epoch','FontName','Times New Roman','FontSize',12,'FontWeight','bold');
ylabel('Step Size','FontName','Times New Roman','FontSize',12,'FontWeight','bold');
title('Step Size (Final)','Interpreter','none','FontName','Times New Roman','FontSize',12);
set(gca,'FontName','Times New Roman','FontSize',12,'Box','on','LineWidth',1,'XColor','k','YColor','k');
%%_______
% ---- 2. Feature importance bar chart ----
figure('Name','Feature Importance','Color','w');

% Get feature names after one-hot encoding
[XtrAll_temp, encAll_temp] = onehot_fit_transform_fast(X_trainTab_all);
allFeatNames = [];

% Build feature name list
numNames = encAll_temp.numVars;
catNames = [];
for j = 1:numel(encAll_temp.catVars)
    for k = 1:numel(encAll_temp.catLevels{j})
        catNames = [catNames, string(encAll_temp.catVars(j)) + "_" + string(encAll_temp.catLevels{j}{k})];
    end
end
allFeatNames = [numNames, catNames];

% Use the Spearman correlations already computed (rvec, order, selIdx from final training)
nShow = min(20, numel(selIdx));
topIdx = selIdx(1:nShow);
scores_show = abs(rvec(topIdx));
scores_show = scores_show / max(scores_show + eps);

% Safe name indexing
if numel(allFeatNames) >= max(topIdx)
    nameShow = allFeatNames(topIdx);
else
    nameShow = arrayfun(@(x) sprintf("Feat_%d",x), topIdx);
end

barh(flipud(scores_show), 'FaceColor', [0.2 0.6 0.4]);
yticks(1:nShow);
yticklabels(flipud(cellstr(nameShow)));
xlabel('|Spearman r| (normalised)', 'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
title(sprintf('Top %d Features Used by Final Model', nShow), ...
    'FontName','Times New Roman','FontSize',12,'FontWeight','bold','Interpreter','none');
grid on;
set(gca,'FontName','Times New Roman','FontSize',12,'TickLabelInterpreter','none');
drawnow;

%% ---- Membership functions (first 6) ----
figure('Name','Membership Functions','Color','w');

nInputsModel = numel(fis_final.Inputs);
nPlot = min(6, nInputsModel);

for inputIdx = 1:nPlot
    try
        [xmf, mfv] = plotmf(fis_final,'input',inputIdx);
        subplot(3,2,inputIdx);
        plot(xmf, mfv, 'k-', 'LineWidth', 1.5);
        grid on;

        xlabel(sprintf('Input %d', inputIdx), 'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
        ylabel('Degree', 'FontName','Times New Roman','FontSize',12,'FontWeight','bold');
        title(sprintf('MFs: Input %d', inputIdx), 'Interpreter','none', ...
              'FontName','Times New Roman','FontSize',12);

        set(gca,'FontName','Times New Roman','FontSize',12,'Box','on', ...
            'LineWidth',1,'XColor','k','YColor','k');
    catch ME
        warning("MF plot failed for input %d: %s", inputIdx, ME.message);
    end
end

%% ============================================================
%  LOCAL FUNCTIONS
%% ============================================================

function [meanR2,stdR2,meanRMSE,meanMAE,meanSMAPE,meanRules,meanParams] = ...
    eval_one_combo_fast(Radius, TopK, StepSize, X_trainTab_all, Y_train_all, foldTr, foldVl, Kfold, ...
                        mfType, numMFs_for_genfis1, GS_MaxEpoch, GS_ErrorGoal, GS_DecRate, GS_IncRate, GS_OptMethod, RANGE_MIN)

    R2_f    = nan(Kfold,1);
    RMSE_f  = nan(Kfold,1);
    MAE_f   = nan(Kfold,1);
    SMAPE_f = nan(Kfold,1);
    nRules_f  = nan(Kfold,1);
    nParams_f = nan(Kfold,1);

    try
        for f = 1:Kfold
            idxTr = foldTr{f};
            idxVl = foldVl{f};

            XtrTab = X_trainTab_all(idxTr,:);
            YtrRaw = Y_train_all(idxTr);

            XvlTab = X_trainTab_all(idxVl,:);
            YvlRaw = Y_train_all(idxVl);

            % ---------- One-hot fit on fold-train only ----------
            [Xtr, enc] = onehot_fit_transform_fast(XtrTab);
            Xvl = onehot_apply_fast(XvlTab, enc);

            % ---------- Clean predictors ----------
            [Xtr, YtrRaw] = make_finite_pair_numeric(Xtr, YtrRaw);
            [Xvl, YvlRaw] = make_finite_pair_numeric(Xvl, YvlRaw);

            % ---------- Min-max fit on fold-train only ----------
            [XtrN, normX] = minmax_fit_transform(Xtr);
            XvlN = minmax_apply(Xvl, normX);
            XvlN = min(max(XvlN,0),1); % clamp numerical drift

            [YtrN, normY] = minmax_fit_transform(YtrRaw(:));
            YvlN = minmax_apply(YvlRaw(:), normY);

            SAFE_EPS = max(0.01*median(abs(YtrRaw(:)),'omitnan'), 1e-6);

            % ---------- Feature ranking (vectorized Spearman) ----------
            rvec = corr(XtrN, YtrN(:), 'Type','Spearman', 'Rows','pairwise'); % 1 x p
            rvec(~isfinite(rvec)) = 0;
            [~, order] = sort(abs(rvec),'descend');

            k_use = min(TopK, numel(order));
            selIdx = order(1:k_use);

            TrIn = XtrN(:,selIdx);
            VlIn = XvlN(:,selIdx);

            % Drop fold-constant cols (on fold-train)
            cr = max(TrIn,[],1) - min(TrIn,[],1);
            keep = cr > 0;
            TrIn = TrIn(:,keep);
            VlIn = VlIn(:,keep);

            if isempty(TrIn) || size(TrIn,1) < 10
                continue
            end

            % ---------- Build initial FIS ----------
            if strcmpi(mfType,'gaussmf')
                opt = genfisOptions('SubtractiveClustering','ClusterInfluenceRange',Radius);
                fis0 = genfis(TrIn, YtrN(:), opt);
            else
                fis0 = genfis1([TrIn YtrN(:)], numMFs_for_genfis1, mfType);
            end

            % Clamp degenerate ranges
            for ii=1:numel(fis0.Inputs)
                lo=fis0.Inputs(ii).Range(1); hi=fis0.Inputs(ii).Range(2);
                if hi-lo < RANGE_MIN
                    mid=(lo+hi)/2;
                    fis0.Inputs(ii).Range=[mid-RANGE_MIN/2, mid+RANGE_MIN/2];
                end
            end

            nRules = numel(fis0.Rules);
            nInp   = numel(fis0.Inputs);
            nParam = nRules*(nInp+1) + nRules*2*nInp;
            nRules_f(f)  = nRules;
            nParams_f(f) = nParam;

            % ---------- Train ANFIS (silent) ----------
            trOpt = [GS_MaxEpoch,GS_ErrorGoal,StepSize,GS_DecRate,GS_IncRate];
            DisplayOff = [false false false false];
            [fis_tr,~,~,~,~] = anfis([TrIn YtrN(:)], fis0, trOpt, DisplayOff, [], GS_OptMethod);

            % make eval range consistent
            for ii=1:numel(fis_tr.Inputs), fis_tr.Inputs(ii).Range=[0,1]; end

            % ---------- Evaluate on fold-validation ----------
            Yvl_hatN = evalfis(fis_tr, VlIn);
            Yvl_hat  = minmax_inverse(Yvl_hatN, normY);
            Yvl_true = YvlRaw(:);

            [R2,RMSE,~,MAE,SMAPE,~] = regression_metrics_plus(Yvl_true, Yvl_hat, SAFE_EPS);

            R2_f(f)    = R2;
            RMSE_f(f)  = RMSE;
            MAE_f(f)   = MAE;
            SMAPE_f(f) = SMAPE;
        end

        meanR2     = mean(R2_f,'omitnan');
        stdR2      = std(R2_f,'omitnan');
        meanRMSE   = mean(RMSE_f,'omitnan');
        meanMAE    = mean(MAE_f,'omitnan');
        meanSMAPE  = mean(SMAPE_f,'omitnan');
        meanRules  = mean(nRules_f,'omitnan');
        meanParams = mean(nParams_f,'omitnan');

    catch
        meanR2=NaN; stdR2=NaN; meanRMSE=NaN; meanMAE=NaN; meanSMAPE=NaN; meanRules=NaN; meanParams=NaN;
    end
end

function [Xmat, enc] = onehot_fit_transform_fast(T)
    varNames = string(T.Properties.VariableNames);
    n = height(T);

    isCat = false(1,width(T));
    for j=1:width(T), isCat(j) = iscategorical(T.(j)); end

    numVars = varNames(~isCat);
    catVars = varNames(isCat);

    % ---- numeric (preallocate) ----
    Xnum = [];
    if ~isempty(numVars)
        Xnum = zeros(n, numel(numVars));
        for j=1:numel(numVars)
            Xnum(:,j) = double(T.(numVars(j)));
        end
    end

    % ---- categorical -> dummyvar (fast) ----
    Xcat = [];
    catLevels = cell(1,numel(catVars));
    if ~isempty(catVars)
        totalCols = 0;
        for j=1:numel(catVars)
            cats = categories(T.(catVars(j)));
            catLevels{j} = cats;
            totalCols = totalCols + numel(cats);
        end
        Xcat = zeros(n, totalCols);

        col0 = 0;
        for j=1:numel(catVars)
            v = T.(catVars(j));
            cats = catLevels{j};
            v = categorical(v, cats);  % lock levels to fold-train categories
            D = dummyvar(v);           % n x nCats
            nc = size(D,2);
            Xcat(:, col0+1:col0+nc) = D;
            col0 = col0 + nc;
        end
    end

    Xmat = [Xnum, Xcat];

    enc.numVars = numVars;
    enc.catVars = catVars;
    enc.catLevels = catLevels;
end

function Xmat = onehot_apply_fast(T, enc)
    n = height(T);

    % numeric
    Xnum = [];
    if ~isempty(enc.numVars)
        Xnum = zeros(n, numel(enc.numVars));
        for j=1:numel(enc.numVars)
            Xnum(:,j) = double(T.(enc.numVars(j)));
        end
    end

    % categorical
    Xcat = [];
    if ~isempty(enc.catVars)
        totalCols = 0;
        for j=1:numel(enc.catVars)
            totalCols = totalCols + numel(enc.catLevels{j});
        end
        Xcat = zeros(n, totalCols);

        col0 = 0;
        for j=1:numel(enc.catVars)
            v = T.(enc.catVars(j));
            cats = enc.catLevels{j};
            v = categorical(v, cats);  % unseen levels -> <undefined> -> dummyvar all zeros
            D = dummyvar(v);
            nc = size(D,2);
            Xcat(:, col0+1:col0+nc) = D;
            col0 = col0 + nc;
        end
    end

    Xmat = [Xnum, Xcat];
end

function [X,y] = make_finite_pair_numeric(X,y)
    X = double(X);
    y = double(y(:));

    X(~isfinite(X)) = NaN;
    y(~isfinite(y)) = NaN;

    bad = isnan(y);
    if any(bad)
        X(bad,:) = [];
        y(bad,:) = [];
    end

    if any(isnan(X),'all')
        for j=1:size(X,2)
            col = X(:,j);
            m = median(col,'omitnan');
            if ~isfinite(m), m = 0; end
            col(isnan(col)) = m;
            X(:,j) = col;
        end
    end
end

function [Xn, normp] = minmax_fit_transform(X)
    X = double(X);
    mn = min(X,[],1);
    mx = max(X,[],1);
    rngv = mx - mn;
    rngv(rngv==0) = 1;
    Xn = (X - mn) ./ rngv;
    normp.min = mn;
    normp.max = mx;
    normp.range = rngv;
end

function Xn = minmax_apply(X, normp)
    X = double(X);
    Xn = (X - normp.min) ./ normp.range;
end

function X = minmax_inverse(Xn, normp)
    X = Xn .* normp.range + normp.min;
end

function [R2,RMSE,MSE,MAE,SMAPE,AARE] = regression_metrics_plus(y,yhat,safe_eps)
    y=y(:); yhat=yhat(:);
    ok=isfinite(y)&isfinite(yhat);
    y=y(ok); yhat=yhat(ok);
    err=y-yhat;

    MSE  = mean(err.^2);
    RMSE = sqrt(MSE);
    MAE  = mean(abs(err));
    

    denom = sum((y-mean(y)).^2);
    R2 = 1 - sum(err.^2)/max(denom,eps);

    SMAPE = mean(200*abs(err)./(abs(y)+abs(yhat)+safe_eps));
    AARE  = mean(100*abs(err)./max(abs(y),safe_eps));
end
function [tab, ax] = local_newTabAx(tg, tabName)
    tab = uitab(tg, 'Title', tabName);
    ax  = axes('Parent', tab);

    set(ax,'FontName','Times New Roman','FontSize',12, ...
        'Box','on','LineWidth',1, ...
        'XColor','k','YColor','k','Color','w');
end