"""
SHAP figures for Fig. 6 (CO2 uptake) and Fig. 9 (Cp), all panels from ONE LOMO run.

For every framework, an XGBoost model is trained on the other frameworks (same data
handling, encoding and hyperparameters as Table 2) and SHAP values are computed for the
held-out framework. One-hot columns are summed back to their original variable.

  panel (a): mean |SHAP| per input variable (bar chart)            -> <target>_SHAP_a_bar
  panel (b): beeswarm of the 20 most important encoded features      -> <target>_SHAP_b_beeswarm
  panel (c): same SHAP values, T and P omitted from the display      -> <target>_SHAP_c_beeswarm_noTP
  also saves per-point SHAP values (variable level and encoded level) as CSV

Usage:   Jupyter: set TARGET = "CO2" or "Cp" below and run the cell.
         Terminal: python SHAP_LOMO_panels.py CO2   (or)   python SHAP_LOMO_panels.py Cp
Needs:   MLDAC01.xlsx and cp_lomo_v2.py in the same folder; xgboost, shap, pandas, matplotlib.
Run time: a few minutes per target (57 or 54 models).
"""
import sys
import numpy as np
import pandas as pd
import xgboost as xgb
import shap
import matplotlib.pyplot as plt
from matplotlib import font_manager
from cp_lomo_v2 import load_dataset, encode_fold_onehot

# ---- choose the target here when running in Jupyter: "CO2" (Fig. 6) or "Cp" (Fig. 9) ----
TARGET = "CO2"
# Beeswarm panels (b) and (c): True = leave out the placeholder categories for empty cells
# ("Topology: not assigned", "Secondary linker: none"). They stay in the model and in panel (a);
# the script prints their mean |SHAP| so you can state it in the caption.
HIDE_PLACEHOLDERS = True
# from a terminal, "python SHAP_LOMO_panels.py Cp" overrides the line above
if len(sys.argv) > 1 and sys.argv[1] in ("CO2", "Cp"):
    TARGET = sys.argv[1]
print("Target:", TARGET)
NUM = ["LCD", "PLD", "Cp", "ThermalSatb", "BET", "Vp", "Enthalpy", "T", "P"]
CFG = {   # hyperparameters as used for Table 2 (CO2: LOMO-selected candidate; Cp: CV-best)
    "CO2": ("CO2uptake", dict(n_estimators=1200, subsample=0.9, colsample_bytree=0.9, reg_lambda=0.5),
            "mmol/g", 1.0),
    "Cp": ("Cp", dict(n_estimators=1500, subsample=0.9, colsample_bytree=0.9, reg_lambda=0.5),
           "10$^{-3}$ J/(g·K)", 1000.0),
}
target, hp, unit, scale = CFG[TARGET]
PARAMS = dict(learning_rate=0.2, max_depth=3, reg_alpha=0.1, objective="reg:squarederror",
              random_state=42, n_jobs=1, verbosity=0, **hp)

LABELS = {"T": "Temperature (K)", "MetalType": "Metal type", "ThermalSatb": r"Thermal stability ($\degree$C)",
          "BET": r"BET surface area (m$^{2}$/g)", "Topology": "Topology", "PLD": "PLD (Å)",
          "Enthalpy": r"Adsorption enthalpy (kJ/mol)", "LCD": "LCD (Å)", "Lp": "Primary linker",
          "Vp": r"Pore volume (cm$^{3}$/g)", "Ls": "Secondary linker",
          "SynthesisMethod": "Synthesis method", "P": "Pressure (bar)", "Cp": r"$C_p$ (J/(g·K))"}

# ---------------- LOMO SHAP ----------------
X, y, g, cat, num = load_dataset("MLDAC01.xlsx", target, "MOF_ID", NUM)
if target == "Cp":
    X = X.drop(columns=["CO2uptake", "MOF_ID"], errors="ignore")
    num = [c for c in num if c in X.columns]
feats = num + cat
S = pd.DataFrame(0.0, index=X.index, columns=feats)       # signed SHAP, summed over dummies
A = S.copy()                                             # |SHAP| summed over dummies (bar-chart convention)
enc_shap, enc_val = [], []                               # encoded (one-hot) level, union over folds
for k, m in enumerate(np.unique(g), 1):
    te = g == m
    Xa, Xb = encode_fold_onehot(X[~te], X[te], cat, num)
    model = xgb.XGBRegressor(**PARAMS).fit(Xa, y[~te])
    sv = pd.DataFrame(shap.TreeExplainer(model).shap_values(Xb), columns=Xb.columns)
    orig = [c.split("__")[0] for c in Xb.columns]
    S.loc[te] = sv.T.groupby(orig).sum().T[feats].values
    A.loc[te] = sv.abs().T.groupby(orig).sum().T[feats].values
    sv.index = X.index[te]; enc_shap.append(sv)
    xb = Xb.copy(); xb.index = X.index[te]; enc_val.append(xb.astype(float))
    print(f"fold {k}: {m}", flush=True)
S.to_csv(f"{TARGET}_LOMO_shap_values.csv", index=False)
E = pd.concat(enc_shap).reindex(X.index).fillna(0.0)          # absent category in a fold -> no contribution
V = pd.concat(enc_val).reindex(X.index)
V = V[E.columns].fillna(0.0)
E.to_csv(f"{TARGET}_LOMO_shap_values_encoded.csv", index=False)
mean_abs = A.mean().sort_values()
print(mean_abs.sort_values(ascending=False).round(4).to_string())

# ---------------- style ----------------
inst = {f.name for f in font_manager.fontManager.ttflist}
FONT = next(f for f in ["Times New Roman", "Liberation Serif", "DejaVu Serif"] if f in inst)
FS = 15
plt.rcParams.update({"font.family": FONT, "font.size": FS, "text.color": "black",
                     "axes.labelcolor": "black", "xtick.color": "black", "ytick.color": "black",
                     "axes.edgecolor": "black", "axes.linewidth": 1.2,
                     "xtick.direction": "in", "ytick.direction": "in",
                     "mathtext.fontset": "custom", "mathtext.rm": FONT,
                     "mathtext.it": FONT + ":italic", "mathtext.default": "rm"})


def box(ax):
    for s in ["top", "right", "bottom", "left"]:
        ax.spines[s].set_visible(True)
        ax.spines[s].set_color("black")


def save(fig, name):
    fig.tight_layout()
    fig.savefig(name + ".png", dpi=600, bbox_inches="tight")
    fig.savefig(name + ".tiff", dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
    print("Saved:", name)


# ---------------- (a) bar chart ----------------
vals = mean_abs * scale
fig, ax = plt.subplots(figsize=(8.5, 6))
ax.barh([LABELS.get(f, f) for f in vals.index], vals, color="#2a6f97", height=0.65)
for i, v in enumerate(vals):
    ax.text(v + vals.max() * 0.015, i, f"{v:.2f}" if scale == 1 else f"{v:.1f}", va="center", fontsize=FS - 2)
ax.set_xlabel(f"Mean |SHAP| ({unit})", fontsize=FS + 1)
ax.set_xlim(0, vals.max() * 1.15)
ax.set_ylim(-0.6, len(vals) - 0.4)
ax.tick_params(axis="y", length=0)
ax.tick_params(axis="x", top=True)
box(ax)
save(fig, f"{TARGET}_SHAP_a_bar")

# ---------------- (b) and (c) beeswarm at encoded-feature level ----------------
def clean(s):
    """Tidy category names for figure labels only (stray spaces, zero-width and no-break characters).
    The placeholder category for an empty cell ("Missing") is shown as "not reported"."""
    s = " ".join(str(s).replace("\u200b", "").replace("\xa0", " ").split())
    return "not reported" if s == "Missing" else s


def enc_label(c):
    if "__" in c:
        v, lev = c.split("__", 1)
        lev = clean(lev)
        if lev == "not reported":          # empty cell in the dataset
            lev = "none" if v == "Ls" else "not assigned"
        return f"{LABELS.get(v, v)}: {lev}"
    return LABELS.get(c, c)


def beeswarm(cols_excluded, name, top=20):
    if HIDE_PLACEHOLDERS:
        cols_excluded = list(cols_excluded) + [c for c in E.columns if c.endswith("__Missing")]
    imp = E.abs().mean().drop(labels=[c for c in cols_excluded if c in E.columns]).sort_values(ascending=False)
    cols = list(imp.index[:top])
    plt.figure()
    shap.summary_plot((E[cols] * scale).values, V[cols].values, feature_names=[enc_label(c) for c in cols],
                      sort=False, show=False, plot_size=(9.5, 8), max_display=top)
    fig, ax = plt.gcf(), plt.gca()
    ax.set_xlabel(f"SHAP value ({unit})", fontsize=FS + 1)
    for t in ax.get_yticklabels() + ax.get_xticklabels():
        t.set_fontsize(FS - 1); t.set_color("black"); t.set_fontfamily(FONT)
    box(ax)
    cb = fig.axes[-1]
    cb.set_ylabel("Feature value", fontsize=FS, family=FONT, color="black")
    for t in cb.get_yticklabels():
        t.set_fontsize(FS - 1); t.set_fontfamily(FONT)
    save(fig, name)
    return cols


if HIDE_PLACEHOLDERS:
    hid = E[[c for c in E.columns if c.endswith("__Missing")]].abs().mean() * scale
    print(f"Hidden from beeswarms (mean |SHAP|, {unit}):", {k: round(float(v), 3) for k, v in hid.items()})
cols_b = beeswarm([], f"{TARGET}_SHAP_b_beeswarm")
cols_c = beeswarm(["T", "P"], f"{TARGET}_SHAP_c_beeswarm_noTP")

# direction of each numeric input (Spearman between input value and its SHAP value)
from scipy.stats import spearmanr
print("\nDirection (Spearman rho, value vs SHAP):")
for c in num:
    if c in E.columns:
        r = spearmanr(V[c], E[c], nan_policy="omit").correlation
        print(f"  {c:12s} {r:+.2f}")
print("\nTop encoded features (mean |SHAP|):")
print(E.abs().mean().sort_values(ascending=False).head(25).round(4).to_string())
