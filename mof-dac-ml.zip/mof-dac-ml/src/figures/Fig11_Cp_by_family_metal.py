"""
Fig. 11 (regenerated): mean reference Cp by MOF family and metal.

Same layout as the original Fig. 11 (families on the x-axis, one bar per metal within a
family, metal written inside the bar, error bars = standard deviation over data points,
dashed line = dataset mean), with the grouping corrected:
  * metals are never pooled: SIFSIX-3-Cu, SIFSIX-18-Ni-beta and TIFSIX-17-Ni are separate bars;
  * all 54 frameworks with a Cp value are included (MIL-101, MIL-47, MIL-96, UTSA-62a,
    soc-MOF, NOTT-300, SC-Ce-MOF-2 and LIFM-26 were missing from the original figure).
Bars are means over all data points of the frameworks in each family-metal group.

Usage:  python Fig11_Cp_by_family_metal.py        (Jupyter: just run the cell)
Needs:  MLDAC01.xlsx in the same folder.
Output: Fig11_Cp_by_family_metal.png/.tiff (600 dpi) and Fig11_Cp_values.xlsx
"""
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager

d = pd.read_excel("MLDAC01.xlsx").dropna(subset=["Cp"])
d["Metal"] = d["MetalType"].astype(str).str.replace("AI", "Al")


def family(m):
    rules = [("CALF", "CALF"), ("PCN", "PCN"), ("SIFSIX", "SIFSIX/TIFSIX"), ("TIFSIX", "SIFSIX/TIFSIX"),
             ("CPM", "CPM"), ("NbOFFIVE", "NbOFFIVE"), ("UTSA", "UTSA"), ("ZIF", "ZIF"), ("UiO", "UiO"),
             ("HKUST", "HKUST"), ("IRMOF", "IRMOF"), ("SNNU", "SNNU"), ("SNU", "SNU"),
             ("MOF-74", "MOF-74"), ("MIL", "MIL"), ("soc-MOF", "soc-MOF"), ("NOTT", "NOTT"),
             ("SC-Ce", "SC-Ce-MOF"), ("LIFM", "LIFM")]
    for key, fam in rules:
        if m.startswith(key):
            return fam
    return m


d["Family"] = d["MOF_ID"].map(family)
FAM_ORDER = ["CALF", "PCN", "SIFSIX/TIFSIX", "CPM", "NbOFFIVE", "UTSA", "ZIF", "UiO", "HKUST",
             "IRMOF", "SNU", "MOF-74", "SNNU", "MIL", "soc-MOF", "NOTT", "SC-Ce-MOF", "LIFM"]
METAL_ORDER = {"MOF-74": ["Mg", "Ni", "Co", "Cu", "Fe"]}

g = (d.groupby(["Family", "Metal"])
       .agg(mean=("Cp", "mean"), sd=("Cp", "std"), n=("Cp", "size"),
            frameworks=("MOF_ID", lambda s: ", ".join(sorted(s.unique()))))
       .reset_index())
g["sd"] = g["sd"].fillna(0.0)
g.to_excel("Fig11_Cp_values.xlsx", index=False)
print(g.round(4).to_string())

COL = {"Zn": "#86c98a", "Cu": "#dd8a2b", "Ni": "#3d9a5a", "Ni/Nb": "#8a83c0", "Ni/Ti": "#5fa8a0",
       "Tb": "#a8664a", "Yb": "#c9a26b", "Mn": "#e2468f", "Zr": "#9b9b96", "Mg": "#3b82c0",
       "Co": "#a65bb8", "Fe": "#d62f2f", "Cd": "#f79a2a", "Al/Ca": "#b3b3b3", "Al": "#5ec4d6",
       "Cr": "#7a6a3a", "V": "#c7c34a", "In": "#6f8fbf", "Ce": "#b07ab0"}

inst = {f.name for f in font_manager.fontManager.ttflist}
FONT = next(f for f in ["Times New Roman", "Liberation Serif", "DejaVu Serif"] if f in inst)
plt.rcParams.update({"font.family": FONT, "font.size": 13, "text.color": "black",
                     "axes.labelcolor": "black", "xtick.color": "black", "ytick.color": "black",
                     "axes.linewidth": 1.2, "mathtext.fontset": "custom", "mathtext.rm": FONT,
                     "mathtext.it": FONT + ":italic", "mathtext.bf": FONT + ":bold:italic"})

YMIN = 0.48
fig, ax = plt.subplots(figsize=(17, 6.5))
x, ticks, labels = 0.0, [], []
for fam in FAM_ORDER:
    sub = g[g["Family"] == fam]
    if sub.empty:
        continue
    order = METAL_ORDER.get(fam, list(sub.sort_values("mean", ascending=False)["Metal"]))
    sub = sub.set_index("Metal").loc[order].reset_index()
    xs = []
    for _, r in sub.iterrows():
        ax.bar(x, r["mean"] - YMIN, bottom=YMIN, width=0.8, color=COL.get(r["Metal"], "#999999"))
        if r["sd"] > 0:
            ax.errorbar(x, r["mean"], yerr=r["sd"], color="black", capsize=4, lw=1.2)
        short = r["mean"] - YMIN < 0.06                 # label above very short bars
        ax.text(x, (r["mean"] + r["sd"] + 0.008) if short else YMIN + 0.01, r["Metal"],
                rotation=90, ha="center", va="bottom", fontsize=12, fontweight="bold")
        xs.append(x)
        x += 0.9
    ticks.append(sum(xs) / len(xs))
    labels.append(fam)
    x += 0.7                                         # gap between families

ax.axhline(d["Cp"].mean(), color="black", ls="--", lw=1.8)
ax.set_xticks(ticks)
ax.set_xticklabels(labels, rotation=30, ha="right", fontweight="bold")
ax.set_ylabel(r"Mean $\mathbf{C_p}$ (J/(g·K))", fontweight="bold", fontsize=14)
ax.set_ylim(YMIN, 1.07)
ax.set_xlim(-0.8, x - 0.3)
for s in ["top", "right", "bottom", "left"]:
    ax.spines[s].set_visible(True)
fig.tight_layout()
fig.savefig("Fig11_Cp_by_family_metal.png", dpi=600, bbox_inches="tight")
fig.savefig("Fig11_Cp_by_family_metal.tiff", dpi=600, bbox_inches="tight",
            pil_kwargs={"compression": "tiff_lzw"})
print(f"Dataset mean Cp (dashed line): {d['Cp'].mean():.3f} J/(g·K)")
print("Saved: Fig11_Cp_by_family_metal.png/.tiff, Fig11_Cp_values.xlsx")
