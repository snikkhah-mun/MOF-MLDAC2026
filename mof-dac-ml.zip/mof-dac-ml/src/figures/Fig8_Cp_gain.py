"""
Fig. 8 (regenerated): gain-based feature importance of the corrected XGBoost Cp model
(MOF_ID and CO2 uptake NOT used as inputs).

Trains exactly the Table 2 random-split model (80/20, seed 42, same encoding and
hyperparameters as Fig. 9 / Table S-7) and prints its test R2 so you can confirm it is the same
model (Table 2: test R2 = 0.9912). Gain importance of the one-hot columns is summed
back to the original variable and expressed as % of total.

Usage:   python Fig8_Cp_gain.py          (Jupyter: just run the cell)
Needs:   MLDAC01.xlsx in the same folder (no other files); xgboost, pandas, matplotlib.
Output:  Fig8_Cp_gain.png/.tiff (panel a), Fig8_Cp_gain_b.png/.tiff (panel b, top 20 encoded features), CSV values
"""
import pandas as pd
import xgboost as xgb
import matplotlib.pyplot as plt
from matplotlib import font_manager

# ---------------- helper functions (copied from cp_lomo_v2.py, so no extra file is needed) ----------------
import numpy as np

def regression_metrics(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    err = y_true - y_pred
    mse = np.mean(err ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(err))
    denom = np.sum((y_true - y_true.mean()) ** 2)
    r2 = 1 - np.sum(err ** 2) / denom if denom > 0 else np.nan
    aare = 100 * np.mean(np.abs(err) / np.maximum(np.abs(y_true), 1e-12))
    return r2, rmse, mae, aare


def load_dataset(file_path, target, group_col, likely_numeric_cols, cat_missing_label="Missing"):
    """Loads the dataset, coercing intended-numeric columns explicitly
    (catches e.g. a single stray non-numeric cell that would otherwise
    force an entire column to be read as text and silently one-hot
    encoded).

    cat_missing_label: categorical NaNs are filled with this literal
    string BEFORE one-hot encoding, so a missing category gets its own
    explicit dummy column (e.g. 'Topology__Missing') rather than
    resulting in an all-zero row across every dummy for that variable.
    This matches your MATLAB pipeline's behavior, where
    categorical(string(NaN)) produces a literal "NaN" category with its
    own column -- i.e. the model has an explicit signal for "topology
    unknown" rather than no signal at all. Set to None to instead leave
    missing rows as all-zero (pandas' default get_dummies behavior).
    """
    df = pd.read_excel(file_path)
    df.columns = [c.strip() for c in df.columns]
    df = df.dropna(subset=[target]).reset_index(drop=True)

    y = df[target].values
    groups = df[group_col].astype(str).values
    X_raw = df.drop(columns=[target, group_col])

    for col in likely_numeric_cols:
        if col in X_raw.columns and X_raw[col].dtype == object:
            coerced = pd.to_numeric(X_raw[col], errors="coerce")
            n_bad = coerced.isna().sum() - X_raw[col].isna().sum()
            if n_bad > 0:
                print(f"WARNING: column '{col}' had {n_bad} non-numeric entries; coercing to NaN.")
            X_raw[col] = coerced

    cat_cols = X_raw.select_dtypes(include=["object"]).columns.tolist()
    num_cols = [c for c in X_raw.columns if c not in cat_cols]

    if cat_missing_label is not None:
        for col in cat_cols:
            n_missing = X_raw[col].isna().sum()
            if n_missing > 0:
                print(f"NOTE: column '{col}' had {n_missing} missing values; "
                      f"filled with explicit '{cat_missing_label}' category (matches MATLAB behavior).")
                X_raw[col] = X_raw[col].fillna(cat_missing_label)

    return X_raw, y, groups, cat_cols, num_cols


def encode_fold_onehot(X_train_raw, X_test_raw, cat_cols, num_cols):
    """One-hot encode using TRAIN categories as the reference column set.
    Test data is reindexed to match exactly -- eliminates the
    shape-mismatch crash class seen in the MATLAB pipeline entirely."""
    X_train_cat = pd.get_dummies(X_train_raw[cat_cols], prefix_sep="__") if cat_cols else pd.DataFrame(index=X_train_raw.index)
    X_test_cat = pd.get_dummies(X_test_raw[cat_cols], prefix_sep="__") if cat_cols else pd.DataFrame(index=X_test_raw.index)
    X_test_cat = X_test_cat.reindex(columns=X_train_cat.columns, fill_value=0)

    X_train_enc = pd.concat([X_train_raw[num_cols].reset_index(drop=True), X_train_cat.reset_index(drop=True)], axis=1)
    X_test_enc = pd.concat([X_test_raw[num_cols].reset_index(drop=True), X_test_cat.reset_index(drop=True)], axis=1)
    return X_train_enc, X_test_enc


def run_random_split(X_raw, y, model_factory, cat_cols, num_cols, test_ratio=0.20, seed=42,
                      encode_fn=encode_fold_onehot):
    """Single random 80/20 split evaluation -- mirrors your MATLAB
    'Table 3' protocol (trainSummary / testSummary / allSummary). This
    is the INTERPOLATION baseline, kept separate from the LOMO
    generalization evaluation in run_lomo() below."""
    n = len(y)
    rng = np.random.RandomState(seed)
    idx = rng.permutation(n)
    n_test = round(test_ratio * n)
    test_idx = idx[:n_test]
    train_idx = idx[n_test:]

    X_train_raw = X_raw.iloc[train_idx]
    X_test_raw = X_raw.iloc[test_idx]
    y_train, y_test = y[train_idx], y[test_idx]

    X_train_enc, X_test_enc = encode_fn(X_train_raw, X_test_raw, cat_cols, num_cols)

    model = model_factory()
    model.fit(X_train_enc, y_train)

    y_pred_train = model.predict(X_train_enc)
    y_pred_test = model.predict(X_test_enc)
    y_all_true = np.concatenate([y_train, y_test])
    y_all_pred = np.concatenate([y_pred_train, y_pred_test])

    train_metrics = regression_metrics(y_train, y_pred_train)
    test_metrics = regression_metrics(y_test, y_pred_test)
    all_metrics = regression_metrics(y_all_true, y_all_pred)

    names = ["R2", "RMSE", "MAE", "AARE_pct"]
    return dict(
        train=dict(zip(names, train_metrics)),
        test=dict(zip(names, test_metrics)),
        all=dict(zip(names, all_metrics)),
        model=model,
        train_idx=train_idx, test_idx=test_idx,
        X_train_enc=X_train_enc, X_test_enc=X_test_enc,
    )


def clean(s):
    """Tidy category names for figure labels only (stray spaces, zero-width and no-break characters).
    The placeholder category for an empty cell ("Missing") is shown as "not reported"."""
    s = " ".join(str(s).replace("\u200b", "").replace("\xa0", " ").split())
    return "not reported" if s == "Missing" else s


# Panel (b): set to True to leave out the placeholder categories for empty cells
# ("Topology: not assigned", "Secondary linker: none"). They stay in the model and in panel (a);
# if you hide them, say so in the caption.
HIDE_PLACEHOLDERS = True

NUM = ["LCD", "PLD", "Cp", "ThermalSatb", "BET", "Vp", "Enthalpy", "T", "P"]
PARAMS = dict(learning_rate=0.2, n_estimators=1500, max_depth=3, subsample=0.9, colsample_bytree=0.9,
              reg_lambda=0.5, reg_alpha=0.1, objective="reg:squarederror",
              random_state=42, n_jobs=1, verbosity=0)          # CV-best Cp model (same as SHAP_LOMO_panels.py, Cp)

X, y, g, cat, num = load_dataset("MLDAC01.xlsx", "Cp", "MOF_ID", NUM)
X = X.drop(columns=["CO2uptake"], errors="ignore")          # leak column removed
num = [c for c in num if c in X.columns and c != "Cp"]
res = run_random_split(X, y, lambda: xgb.XGBRegressor(**PARAMS), cat, num)
print(f"Train R2 = {res['train']['R2']:.4f}   Test R2 = {res['test']['R2']:.4f}   All R2 = {res['all']['R2']:.4f}")
print("(Table 2: 0.9968 / 0.9912 / 0.9958 - if these differ, this is not the Table 2 model)")

imp = pd.Series(res["model"].feature_importances_, index=res["X_train_enc"].columns)   # gain, normalised
gain = imp.groupby([c.split("__")[0] for c in imp.index]).sum()
gain = 100 * gain / gain.sum()
gain.sort_values(ascending=False).round(2).to_csv("Fig8_Cp_gain_values.csv", header=["Gain_pct"])
print(gain.sort_values(ascending=False).round(2).to_string())

LABELS = {"T": "Temperature (K)", "MetalType": "Metal type", "ThermalSatb": r"Thermal stability ($\degree$C)",
          "BET": r"BET surface area (m$^{2}$/g)", "Topology": "Topology", "PLD": "PLD (Å)",
          "Enthalpy": "Adsorption enthalpy (kJ/mol)", "LCD": "LCD (Å)", "Lp": "Primary linker",
          "Vp": r"Pore volume (cm$^{3}$/g)", "Ls": "Secondary linker",
          "SynthesisMethod": "Synthesis method", "P": "Pressure (bar)", "Cp": r"$C_p$ (J/(g·K))"}

inst = {f.name for f in font_manager.fontManager.ttflist}
FONT = next(f for f in ["Times New Roman", "Liberation Serif", "DejaVu Serif"] if f in inst)
FS = 15
plt.rcParams.update({"font.family": FONT, "font.size": FS, "text.color": "black",
                     "axes.labelcolor": "black", "xtick.color": "black", "ytick.color": "black",
                     "axes.edgecolor": "black", "axes.linewidth": 1.2,
                     "xtick.direction": "in", "ytick.direction": "in",
                     "mathtext.fontset": "custom", "mathtext.rm": FONT,
                     "mathtext.it": FONT + ":italic", "mathtext.default": "rm"})

v = gain.sort_values()
fig, ax = plt.subplots(figsize=(8.5, 6))
ax.barh([LABELS.get(f, f) for f in v.index], v, color="#2a6f97", height=0.65)
for i, val in enumerate(v):
    ax.text(val + v.max() * 0.015, i, f"{val:.1f}", va="center", fontsize=FS - 2)
ax.set_xlabel("Gain importance (%)", fontsize=FS + 1)
ax.set_xlim(0, v.max() * 1.15)
ax.set_ylim(-0.6, len(v) - 0.4)
ax.tick_params(axis="y", length=0)
ax.tick_params(axis="x", top=True)
for s in ["top", "right", "bottom", "left"]:
    ax.spines[s].set_visible(True)
fig.tight_layout()
fig.savefig("Fig8_Cp_gain.png", dpi=600, bbox_inches="tight")
fig.savefig("Fig8_Cp_gain.tiff", dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
print("Saved: Fig8_Cp_gain.png/.tiff, Fig8_Cp_gain_values.csv")

# ---------------- panel (b): top 20 individual encoded features ----------------
def enc_label(c):
    if "__" in c:
        v, lev = c.split("__", 1)
        lev = clean(lev)
        if lev == "not reported":          # empty cell in the dataset
            lev = "none" if v == "Ls" else "not assigned"
        return f"{LABELS.get(v, v)}: {lev}"
    return LABELS.get(c, c)

pct = 100 * imp.astype(float) / float(imp.sum())
if HIDE_PLACEHOLDERS:
    hidden = [c for c in pct.index if c.endswith("__Missing")]
    print("Hidden from panel (b):", {c: round(float(pct[c]), 2) for c in hidden})
    pct = pct.drop(hidden)
ind = pct.sort_values(ascending=False).head(20).sort_values()
ind.sort_values(ascending=False).round(2).to_csv("Fig8_Cp_gain_b_values.csv", header=["Gain_pct"])
fig, ax = plt.subplots(figsize=(8.5, 7.5))
ax.barh([enc_label(c) for c in ind.index], ind, color="#2a6f97", height=0.65)
for i, val in enumerate(ind):
    ax.text(val + ind.max() * 0.015, i, f"{val:.1f}", va="center", fontsize=FS - 3)
ax.set_xlabel("Gain importance (%)", fontsize=FS + 1)
ax.set_xlim(0, ind.max() * 1.15)
ax.set_ylim(-0.6, len(ind) - 0.4)
ax.tick_params(axis="y", length=0, labelsize=FS - 2)
ax.tick_params(axis="x", top=True)
for s_ in ["top", "right", "bottom", "left"]:
    ax.spines[s_].set_visible(True)
fig.tight_layout()
fig.savefig("Fig8_Cp_gain_b.png", dpi=600, bbox_inches="tight")
fig.savefig("Fig8_Cp_gain_b.tiff", dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
print(ind.sort_values(ascending=False).round(2).to_string())
print("Saved: Fig8_Cp_gain_b.png/.tiff, Fig8_Cp_gain_b_values.csv")
