"""
Fig. S-X (DAC-condition predictions) and Table S-Y, in one script.

1. Trains the random-split XGBoost CO2 model of Table 2 and predicts uptake at 4e-4 bar,
   mean over 273-313 K, for all 57 frameworks  -> DAC_predictions_all_MOFs.xlsx
2. Draws the frameworks with a positive prediction, coloured by metal type:
   version A (ranked) and version B (grouped by metal) -> Fig7_A_ranked_by_metal / Fig7_B_grouped_by_metal
3. Writes the matching table with LOMO accuracy and data ranges -> TableSY_DAC_LOMO.xlsx

Needs (same folder): MLDAC01.xlsx and XGB_LOMO_bestparams_onehot_perfold.csv
Packages: numpy, pandas, xgboost, matplotlib, openpyxl.  Works in Jupyter or a terminal.
"""
import numpy as np
import pandas as pd
import xgboost as xgb
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch

DATA, PERFOLD = "MLDAC01.xlsx", "XGB_LOMO_bestparams_onehot_perfold.csv"
P_DAC, T_GRID = 4e-4, np.arange(273, 314)
NUM = ["LCD", "PLD", "Cp", "ThermalSatb", "BET", "Vp", "Enthalpy", "T", "P"]
PARAMS = dict(learning_rate=0.2, n_estimators=1200, max_depth=3, subsample=0.9,
              colsample_bytree=0.9, reg_lambda=0.5, reg_alpha=0.1,
              objective="reg:squarederror", random_state=42, n_jobs=1, verbosity=0)
TOP_N = 14

# ---------------- data (same handling as the Table 2 notebooks) ----------------
df = pd.read_excel(DATA)
df.columns = [c.strip() for c in df.columns]
df = df.dropna(subset=["CO2uptake"]).reset_index(drop=True)
y = df["CO2uptake"].values
groups = df["MOF_ID"].astype(str).values
X = df.drop(columns=["CO2uptake", "MOF_ID"])
for c in NUM:
    if c in X and X[c].dtype == object:
        X[c] = pd.to_numeric(X[c], errors="coerce")
cat = X.select_dtypes(include=["object", "string"]).columns.tolist()
num = [c for c in X.columns if c not in cat]
for c in cat:
    X[c] = X[c].fillna("Missing")

def encode(train_raw, other_raw):
    tr = pd.get_dummies(train_raw[cat], prefix_sep="__")
    ot = pd.get_dummies(other_raw[cat], prefix_sep="__").reindex(columns=tr.columns, fill_value=0)
    a = pd.concat([train_raw[num].reset_index(drop=True), tr.reset_index(drop=True)], axis=1)
    b = pd.concat([other_raw[num].reset_index(drop=True), ot.reset_index(drop=True)], axis=1)
    return a, b

# random 80/20 split, seed 42 (as in Table 2)
idx = np.random.RandomState(42).permutation(len(y))
n_test = round(0.2 * len(y))
tr_idx = idx[n_test:]
X_tr, _ = encode(X.iloc[tr_idx], X.iloc[tr_idx])
model = xgb.XGBRegressor(**PARAMS).fit(X_tr, y[tr_idx])

# ---------------- DAC predictions for every framework ----------------
rows = []
for mof in sorted(set(groups)):
    Xm = X[groups == mof]
    base = Xm.iloc[0]
    t, cp = Xm["T"].astype(float).values, Xm["Cp"].astype(float).values
    ok = ~np.isnan(cp)
    grid = []
    for T in T_GRID:
        r = base.copy()
        r["T"], r["P"] = T, P_DAC
        if ok.any():
            o = np.argsort(t[ok])
            r["Cp"] = np.interp(T, t[ok][o], cp[ok][o])
        grid.append(r)
    _, Xg = encode(X.iloc[tr_idx], pd.DataFrame(grid))
    pred = model.predict(Xg[X_tr.columns])
    w = Xm[(Xm["T"] >= 273) & (Xm["T"] <= 313)]
    rows.append(dict(MOF=mof, Pred_mean=pred.mean(), Pred_min=pred.min(), Pred_max=pred.max(),
                     Min_measured_P_273_313K=w["P"].min() if len(w) else np.nan))
res = pd.DataFrame(rows).sort_values("Pred_mean", ascending=False).reset_index(drop=True)
res["Near_DAC_data"] = res["Min_measured_P_273_313K"] <= 4e-3
pf = pd.read_csv(PERFOLD).set_index("MOF")
res["LOMO_R2"] = res["MOF"].map(pf["R2"])
res["LOMO_AARE_pct"] = res["MOF"].map(pf["AARE_pct"])
res["LOMO_n"] = res["MOF"].map(pf["n_test"])
res.to_excel("DAC_predictions_all_MOFs.xlsx", index=False)

n_neg = int((res["Pred_mean"] < 0).sum())
print(f"Frameworks with negative mean predicted uptake: {n_neg} of {len(res)}")
print(res.head(TOP_N)[["MOF", "Pred_mean", "LOMO_R2", "LOMO_AARE_pct", "Near_DAC_data"]].round(3).to_string())

inst = {f.name for f in font_manager.fontManager.ttflist}
FONT = next(f for f in ["Times New Roman", "Liberation Serif", "DejaVu Serif"] if f in inst)
plt.rcParams.update({"font.family": FONT, "font.size": 13, "text.color": "black",
                     "axes.labelcolor": "black", "xtick.color": "black", "ytick.color": "black",
                     "axes.linewidth": 1.2, "xtick.direction": "out", "ytick.direction": "out",
                     "mathtext.fontset": "custom", "mathtext.rm": FONT, "mathtext.default": "rm"})

metal = pd.read_excel("MLDAC01.xlsx").groupby("MOF_ID")["MetalType"].first().str.replace("AI", "Al")
top = res[res["Pred_mean"] > 0].head(TOP_N).copy()   # positive predictions only
print(f"Bars shown: {len(top)} (frameworks with negative predictions: {(res['Pred_mean'] <= 0).sum()} of {len(res)})")
top["Metal"] = top["MOF"].map(metal)

# colours of the original Fig. 7, plus new metals
COL = {"Cu": "#ff7f0e", "Zn": "#2ca02c", "Al/Ca": "#d62728", "Ni": "#9467bd", "Al": "#17becf",
       "Co": "#aec7e8", "Mg": "#ffbb78", "Ni/Nb": "#98df8a",
       "Mn": "#8c564b", "Zr": "#e377c2", "Cd": "#7f7f7f"}
YLAB = r"Predicted CO$_2$ uptake at DAC conditions (mmol/g)"


def finish(fig, ax, metals_order, name):
    ax.axhline(0, color="black", lw=1)
    ax.set_ylabel(YLAB)
    ax.set_ylim(0, top["Pred_mean"].max() * 1.08)
    for s in ["top", "right", "bottom", "left"]:
        ax.spines[s].set_visible(True)
    plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
    ax.legend(handles=[Patch(facecolor=COL[m], label=m) for m in metals_order],
              title="Metal type", loc="upper right", frameon=True, edgecolor="black",
              fontsize=11, title_fontsize=12)
    fig.tight_layout()
    fig.savefig(name + ".png", dpi=600, bbox_inches="tight")
    fig.savefig(name + ".tiff", dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
    print("Saved:", name)


# ---------- A: descending order, coloured by metal ----------
fig, ax = plt.subplots(figsize=(11, 7))
ax.bar(top["MOF"], top["Pred_mean"], color=top["Metal"].map(COL), width=0.7)
finish(fig, ax, list(dict.fromkeys(top["Metal"])), "Fig7_A_ranked_by_metal")

# ---------- B: grouped by metal type ----------
order = top.groupby("Metal")["Pred_mean"].max().sort_values(ascending=False).index
xs, labels, colors, vals, centers, x = [], [], [], [], [], 0.0
for m in order:
    g = top[top["Metal"] == m].sort_values("Pred_mean", ascending=False)
    start = x
    for _, r in g.iterrows():
        xs.append(x); labels.append(r["MOF"]); colors.append(COL[m]); vals.append(r["Pred_mean"]); x += 1
    centers.append(((start + x - 1) / 2, m))
    x += 0.6                                           # gap between metal groups
fig, ax = plt.subplots(figsize=(12, 7))
ax.bar(xs, vals, color=colors, width=0.7)
ax.set_xticks(xs)
ax.set_xticklabels(labels)
ax.set_xlim(-0.7, x - 0.6 + 0.1)
finish(fig, ax, list(order), "Fig7_B_grouped_by_metal")


# ---------- Table S-Y: the frameworks shown in the figure ----------
rng = df.groupby("MOF_ID").agg(Pmin=("P", "min"), Pmax=("P", "max"), Tmin=("T", "min"), Tmax=("T", "max"))
fmtP = lambda m: f"{rng.loc[m,'Pmin']:.2g}" if rng.loc[m,'Pmin'] == rng.loc[m,'Pmax'] else f"{rng.loc[m,'Pmin']:.2g}–{rng.loc[m,'Pmax']:.2g}"
fmtT = lambda m: f"{rng.loc[m,'Tmin']}" if rng.loc[m,'Tmin'] == rng.loc[m,'Tmax'] else f"{rng.loc[m,'Tmin']}–{rng.loc[m,'Tmax']}"
tab = top[["MOF", "Pred_mean", "LOMO_n", "LOMO_R2", "LOMO_AARE_pct", "Near_DAC_data"]].copy()
tab.insert(0, "Order", range(1, len(tab) + 1))
tab.insert(3, "Measured_P_range_bar", tab["MOF"].map(fmtP))
tab.insert(4, "Measured_T_range_K", tab["MOF"].map(fmtT))
tab.to_excel("TableSY_DAC_LOMO.xlsx", index=False)
print(tab.round(3).to_string())
